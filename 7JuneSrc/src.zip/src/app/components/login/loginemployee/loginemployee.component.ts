import { Component, OnInit } from '@angular/core';
import { LoginDetails } from 'src/app/pojo/logindetails';

@Component({
  selector: 'app-loginemployee',
  templateUrl: './loginemployee.component.html',
  styleUrls: ['./loginemployee.component.css']
})
export class LoginemployeeComponent implements OnInit {

  logindetails : LoginDetails = new LoginDetails();
  submitted : boolean = false;
  constructor() { }

  ngOnInit(): void {
  }
  goToHome(){}

  onFormSubmit(){}
}
