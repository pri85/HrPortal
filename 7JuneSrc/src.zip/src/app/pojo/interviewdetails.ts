export class InterviewDetails{
    interviewId : number = 0;
	candidateId : number = 0;
	interviewerId : number = 0;
	status : string = "";
	feedback : string = "";
	interviewDate : Date = new Date();
	// candidateDetails:;
	// employeeDetails : ;
}