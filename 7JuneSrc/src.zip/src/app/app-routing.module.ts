import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginemployeeComponent } from './components/login/loginemployee/loginemployee.component';

const routes: Routes = [
  {path:'loginemployee', component: LoginemployeeComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
