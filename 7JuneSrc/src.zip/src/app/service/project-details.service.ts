import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ProjectDetails } from '../pojo/projectdetails';

@Injectable({
  providedIn: 'root'
})
export class ProjectDetailsService {



  baseURL : string = "http://localhost:8080/projectdetails/projectdetail";

  constructor(private http: HttpClient) { }

  getSingleEmployee(projectId : number) : Observable<ProjectDetails>{
    return this.http.get<ProjectDetails>(this.baseURL+'/'+ projectId);
  }

  getAllEmployees() : Observable<ProjectDetails[]>{
    return this.http.get<ProjectDetails[]>(this.baseURL);
    }

}
