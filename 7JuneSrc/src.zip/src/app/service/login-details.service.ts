import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { LoginDetails } from '../pojo/logindetails';

@Injectable({
  providedIn: 'root'
})
export class LoginDetailsService {

  baseURL : string = "http://localhost:8080/logindetails/logindetail";

  constructor(private http: HttpClient) { }

    getAllLoginDetails() : Observable<LoginDetails[]>{
    return this.http.get<LoginDetails[]>(this.baseURL);
    }
    getSingleLoginDetails(userId : number) : Observable<LoginDetails>{
      return this.http.get<LoginDetails>(this.baseURL+'/'+ userId);
    }
}
