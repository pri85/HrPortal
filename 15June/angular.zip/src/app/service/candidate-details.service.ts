import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CandidateDetails } from '../pojo/candidatedetails';

@Injectable({
  providedIn: 'root'
})
export class CandidateDetailsService {

  baseURL : string = "http://localhost:8080/candidatedetails";

  constructor(private http: HttpClient) { }

  getSingleCandidateDetails(candidateId : number) : Observable<CandidateDetails>{
    return this.http.get<CandidateDetails>(this.baseURL+'/candidatedetail/'+ candidateId);
  }

  getAllCandidateDetails() : Observable<CandidateDetails[]>{
    return this.http.get<CandidateDetails[]>(this.baseURL+'/candidatedetail/');
    }

    addNewCandidateDetails(candidateDetails : CandidateDetails) : Observable<boolean> {
      console.log("in requrement request service");
      console.log(candidateDetails);
      return this.http.post<boolean>(this.baseURL+'/candidatedetail/',candidateDetails);
  
    }

    updateCandidateDetailsAsInprocess(candidateDetails : CandidateDetails) : Observable<CandidateDetails>{
      return this.http.put<CandidateDetails>(this.baseURL+'/inprocesscandidatedetail',candidateDetails);
    }

    getAllInprocessCandidateDetails() : Observable<CandidateDetails[]>{
      return this.http.get<CandidateDetails[]>(this.baseURL+'/inprocesscandidatedetail');
      }

    getAllNewCandidateDetails() : Observable<CandidateDetails[]>{
        return this.http.get<CandidateDetails[]>(this.baseURL+'/newcandidatedetail');
      }
    getAllSelectedCandidateDetails() : Observable<CandidateDetails[]>{
          return this.http.get<CandidateDetails[]>(this.baseURL+'/selectedcandidatedetail');
      }
    getAllRejectedCandidateDetails() : Observable<CandidateDetails[]>{
            return this.http.get<CandidateDetails[]>(this.baseURL+'/rejectedcandidatedetail');
      }

      getAllPendingCandidateDetails() : Observable<CandidateDetails[]>{
        return this.http.get<CandidateDetails[]>(this.baseURL+'/pendingcandidatedetail');
  }
}
