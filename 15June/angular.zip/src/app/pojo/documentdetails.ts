import { Byte } from "@angular/compiler/src/util";
import { CandidateDetails } from "./candidatedetails";

export class DocumentDetails{
     documentId : number = 0;
	 documentType : string = "";
	 candidateId : number = 0;
	 document : Byte[] = [];
	 candidateDetails : CandidateDetails = new CandidateDetails();
}