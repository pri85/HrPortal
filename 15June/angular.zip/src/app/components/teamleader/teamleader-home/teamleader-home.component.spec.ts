import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamleaderHomeComponent } from './teamleader-home.component';

describe('TeamleaderHomeComponent', () => {
  let component: TeamleaderHomeComponent;
  let fixture: ComponentFixture<TeamleaderHomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeamleaderHomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamleaderHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
