import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-teamleader-home',
  templateUrl: './teamleader-home.component.html',
  styleUrls: ['./teamleader-home.component.css']
})
export class TeamleaderHomeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  logout(){
     this.router.navigate(['/loginemployee']);
  }
}
