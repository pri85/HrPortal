import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateRequirementRequestComponent } from './update-requirement-request.component';

describe('UpdateRequirementRequestComponent', () => {
  let component: UpdateRequirementRequestComponent;
  let fixture: ComponentFixture<UpdateRequirementRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateRequirementRequestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateRequirementRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
