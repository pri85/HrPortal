import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CandidateDetails } from '../pojo/candidatedetails';

@Injectable({
  providedIn: 'root'
})
export class CandidateDetailsService {

  baseURL : string = "http://localhost:8080/documentdetails/documentdetail";

  constructor(private http: HttpClient) { }

  getSingleCandidateDetails(candidateId : number) : Observable<CandidateDetails>{
    return this.http.get<CandidateDetails>(this.baseURL+'/'+ candidateId);
  }

  getAllCandidateDetails() : Observable<CandidateDetails[]>{
    return this.http.get<CandidateDetails[]>(this.baseURL);
    }
}
