import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from '../pojo/employeedetails';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {

  baseURL : string = "http://localhost:8080/employeedetails/employeedetail";

  constructor(private http: HttpClient) { }

  getSingleEmployeeDetails(employeeId : number) : Observable<EmployeeDetails>{
    return this.http.get<EmployeeDetails>(this.baseURL+'/'+ employeeId);
  }

  getAllEmployeeDetails() : Observable<EmployeeDetails[]>{
    return this.http.get<EmployeeDetails[]>(this.baseURL);
    }
}
