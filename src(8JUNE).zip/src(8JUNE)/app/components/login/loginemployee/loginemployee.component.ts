import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { LoginDetails } from 'src/app/pojo/logindetails';
import { LoginDetailsService } from 'src/app/service/login-details.service';

@Component({
  selector: 'app-loginemployee',
  templateUrl: './loginemployee.component.html',
  styleUrls: ['./loginemployee.component.css']
})
export class LoginemployeeComponent implements OnInit {

  logindetails: LoginDetails = new LoginDetails();
  submitted: boolean = false;
  userId: number = 0;
  constructor(private logindetailsservices: LoginDetailsService, private router: Router) { }

  ngOnInit(): void {
  }
  goToHome() { }

  onFormSubmit() {
    this.submitted = true;
    console.log(this.logindetails);
    this.logindetailsservices.validateUser(this.logindetails).subscribe(
      data => {
        this.logindetails = data;
        console.log("after calling service");

        console.log(this.logindetails);

        if (this.logindetails.role === 'HR') {
          this.router.navigate(['/hrhome']);
        }
        if (this.logindetails.role === 'PROJECT MANAGEWR') {
          this.router.navigate(['/projectmanagerhome']);
        }
        if (this.logindetails.role === 'TEAM LEADER') {
          this.router.navigate(['/teamleaderhome']);
        }
        if (this.logindetails.role === 'INTERVIEWER') {
          this.router.navigate(['/interviewerhome']);
        }


      }
    );
  }
}
