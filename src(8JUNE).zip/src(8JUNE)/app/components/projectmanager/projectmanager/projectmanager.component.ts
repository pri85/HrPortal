import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-projectmanager',
  templateUrl: './projectmanager.component.html',
  styleUrls: ['./projectmanager.component.css']
})
export class ProjectmanagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
