import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewerComponentComponent } from './interviewer-component.component';

describe('InterviewerComponentComponent', () => {
  let component: InterviewerComponentComponent;
  let fixture: ComponentFixture<InterviewerComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterviewerComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterviewerComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
