import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interviewer-component',
  templateUrl: './interviewer-component.component.html',
  styleUrls: ['./interviewer-component.component.css']
})
export class InterviewerComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
