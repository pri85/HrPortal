import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CandidateComponent } from './components/candidate/candidate/candidate.component';
import { HrComponent } from './components/hr/hr/hr.component';
import { InterviewerComponentComponent } from './components/interviewer/interviewer-component/interviewer-component.component';
import { LoginemployeeComponent } from './components/login/loginemployee/loginemployee.component';
import { ProjectmanagerComponent } from './components/projectmanager/projectmanager/projectmanager.component';
import { TeamleaderComponent } from './components/teamleader/teamleader/teamleader.component';

const routes: Routes = [
  {path:'loginemployee', component: LoginemployeeComponent},
  {path:'candidatehome', component: CandidateComponent},
  {path:'projectmanagerhome', component: ProjectmanagerComponent},
  {path:'teamleaderhome', component: TeamleaderComponent},
  {path:'hrhome', component: HrComponent},
  {path:'interviewerhome', component: InterviewerComponentComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
