package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.pojo.LoginDetails;
import com.mindgate.main.pojo.ProjectDetails;
import com.mindgate.main.pojo.RequirementRequestDetails;
import com.mindgate.main.service.RequirementRequestDetailsServiceInterface;

@RestController
@CrossOrigin(origins = "http://localhost:4200/")
@RequestMapping("requirementrequestdetails")
public class RequirementRequestDetailsController {

	@Autowired
	private RequirementRequestDetailsServiceInterface requestDetailsServiceInterface; 
	
	@RequestMapping(value = "requirementrequestdetail" , method = RequestMethod.GET)
	public List<RequirementRequestDetails> getAllRequirementRequest(){
		return requestDetailsServiceInterface.getAllRequirementRequest();
	}
	
	@RequestMapping(value = "requirementrequestdetail/{requirementrequestid}" , method = RequestMethod.GET)
	public RequirementRequestDetails getRequirementRequestByRequirementRequestId(@PathVariable int requirementrequestid) {
		return requestDetailsServiceInterface.getRequirementRequestByRequirementRequestId(requirementrequestid);
	}
	
	@RequestMapping(value = "requirementrequestdetail" , method = RequestMethod.POST)
	public boolean addNewRequirementRequest(@RequestBody RequirementRequestDetails requirementRequestDetails) {
		return requestDetailsServiceInterface.addNewRequirementRequest(requirementRequestDetails);
	}
	
	@RequestMapping(value = "requirementrequestdetailbyprojectid/{projectid}" , method = RequestMethod.GET)
	public List<RequirementRequestDetails> getAllRequirementRequestByProjectId(@PathVariable int projectid){
		return requestDetailsServiceInterface.getAllRequirementRequestByProjectId(projectid);
	}
	
	
//	@RequestMapping(value = "logindetail" , method = RequestMethod.POST )
//	public LoginDetails login(@RequestBody LoginDetails loginDetails) {
//		System.out.println(loginDetails);
//		return loginDetailsService.login(loginDetails);
//		
//	}
}
