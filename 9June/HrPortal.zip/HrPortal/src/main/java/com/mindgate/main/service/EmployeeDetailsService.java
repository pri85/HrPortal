package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.EmployeeDetails;
import com.mindgate.main.repository.EmployeeDetailsRepositoryInterface;

@Service
public class EmployeeDetailsService implements EmployeeDetailsServiceInterface{

	@Autowired
	private EmployeeDetailsRepositoryInterface employeeDetailsRepository;
	
	@Override
	public boolean addNewEmployee(EmployeeDetails employeeDetails) {

		return employeeDetailsRepository.addNewEmployee(employeeDetails);
	}

	@Override
	public boolean updateEmployeeDetailsByEmployeeId(EmployeeDetails employeeDetails) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.updateEmployeeDetailsByEmployeeId(employeeDetails);
	}

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.deleteEmployeeByEmployeeId(employeeId);
	}

	@Override
	public EmployeeDetails getEmployeeByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.getEmployeeByEmployeeId(employeeId);
	}

	@Override
	public List<EmployeeDetails> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.getAllEmployee();
	}

	@Override
	public EmployeeDetails getEmployeeByUserId(int userid) {
		// TODO Auto-generated method stub
		return 	employeeDetailsRepository.getEmployeeByUserId(userid);
	}

}
