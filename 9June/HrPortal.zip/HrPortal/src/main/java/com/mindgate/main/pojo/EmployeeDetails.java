package com.mindgate.main.pojo;

public class EmployeeDetails {
	 private int employeeId;
	 private String firstName;
	 private String lastName;
	 private Long contactNumber;
	 private String designation;
	 private Double salary;
	 private ProjectDetails projectDetails;
	 private String address;
	 private String city;
	 private String state;
	 private int pincode;
	 private LoginDetails loginDetails;
	 
	 
	public EmployeeDetails() {
		// TODO Auto-generated constructor stub
	}


	public EmployeeDetails(int employeeId, String firstName, String lastName, Long contactNumber2, String designation,
			Double salary, ProjectDetails projectDetails, String address, String city, String state, int pincode,
			LoginDetails loginDetails) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.contactNumber = contactNumber2;
		this.designation = designation;
		this.salary = salary;
		this.projectDetails = projectDetails;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.loginDetails = loginDetails;
	}


	public int getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public Long getContactNumber() {
		return contactNumber;
	}


	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}


	public String getDesignation() {
		return designation;
	}


	public void setDesignation(String designation) {
		this.designation = designation;
	}


	public Double getSalary() {
		return salary;
	}


	public void setSalary(Double salary) {
		this.salary = salary;
	}


	public ProjectDetails getProjectDetails() {
		return projectDetails;
	}


	public void setProjectDetails(ProjectDetails projectDetails) {
		this.projectDetails = projectDetails;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public int getPincode() {
		return pincode;
	}


	public void setPincode(int pincode) {
		this.pincode = pincode;
	}


	public LoginDetails getLoginDetails() {
		return loginDetails;
	}


	public void setLoginDetails(LoginDetails loginDetails) {
		this.loginDetails = loginDetails;
	}


	@Override
	public String toString() {
		return "EmployeeDetails [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", contactNumber=" + contactNumber + ", designation=" + designation + ", salary=" + salary
				+ ", projectDetails=" + projectDetails + ", address=" + address + ", city=" + city + ", state=" + state
				+ ", pincode=" + pincode + ", loginDetails=" + loginDetails + "]";
	}
	
	
}
