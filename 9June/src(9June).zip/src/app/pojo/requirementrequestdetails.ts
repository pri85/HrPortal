import { EmployeeDetails } from "./employeedetails";
import { ProjectDetails } from "./projectdetails";

export class RequirementRequestDetails{
    requirementRequestId : number = 0;
	projectDetails : ProjectDetails = new ProjectDetails();
	skill1 : string = "";
    skill2 : string = "";
	skill3 : string = "";
	experience : number = 0;
	vacancies : number = 0;
	employeeDetails : EmployeeDetails = new EmployeeDetails();
	status : string = "";
	role : string = "";
}