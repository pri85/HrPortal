import { RequirementRequestDetails } from "./requirementrequestdetails";

export class CandidateDetails{
    candidateId : number = 0;
	candidateName : string = "";
	email : string ="";
	skill1 : string ="";
	skill2 : string ="";
	skill3 : string ="";
	qualification : string ="";
    experience : string ="";
	status : string ="";
    location : string ="";
	requirementrequestetails : RequirementRequestDetails = new RequirementRequestDetails();
}