import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from '../pojo/employeedetails';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {

  baseURL: string = "http://localhost:8080/employeedetails";

  constructor(private http: HttpClient) { }

  getSingleEmployeeDetails(employeeId: number): Observable<EmployeeDetails> {
    return this.http.get<EmployeeDetails>(this.baseURL + '/employeedetail/' + employeeId);
  }

  getEmployeeDetailsByUserId(userId: number): Observable<EmployeeDetails> {
    return this.http.get<EmployeeDetails>(this.baseURL + '/employeebyuserid/' + userId);
  }

  getAllEmployeeDetails(): Observable<EmployeeDetails[]> {
    return this.http.get<EmployeeDetails[]>(this.baseURL+ '/employeedetail');
  }
}
