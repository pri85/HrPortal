import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RequirementRequestStatusComponent } from './requirement-request-status.component';

describe('RequirementRequestStatusComponent', () => {
  let component: RequirementRequestStatusComponent;
  let fixture: ComponentFixture<RequirementRequestStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RequirementRequestStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RequirementRequestStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
