import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { ProjectDetails } from 'src/app/pojo/projectdetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { ProjectDetailsService } from 'src/app/service/project-details.service';
import { RequirementRequestDetailsService } from 'src/app/service/requirement-request-details.service';

@Component({
  selector: 'app-update-requirement-request',
  templateUrl: './update-requirement-request.component.html',
  styleUrls: ['./update-requirement-request.component.css']
})
export class UpdateRequirementRequestComponent implements OnInit {

  allRequirementRequestDetails : RequirementRequestDetails [] =[] ;
  requirementRequestDetails : RequirementRequestDetails = new RequirementRequestDetails();
  

  projectId : number = 0;
  constructor(private requirementRequestDetailsService: RequirementRequestDetailsService,private router: Router, private route : ActivatedRoute) { }

  ngOnInit(): void {
    this.reloadData();
    
  }
  reloadData(){
    this.projectId =  this.route.snapshot.params['projectId'];
    
        this.requirementRequestDetailsService.getSingleRequirementRequest(this.projectId).subscribe(
          data =>{
            //this.requirementrequestdetails=data;
            this.requirementRequestDetails=data;
            console.log(this.projectId);
            
            console.log('-----------------------------------');
            
            console.log(this.requirementRequestDetails);
            
          }
        );
  }
}
