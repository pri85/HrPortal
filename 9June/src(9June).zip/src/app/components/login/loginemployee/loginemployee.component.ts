import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { LoginDetails } from 'src/app/pojo/logindetails';
import { EmployeeDetailsService } from 'src/app/service/employee-details.service';
import { LoginDetailsService } from 'src/app/service/login-details.service';

@Component({
  selector: 'app-loginemployee',
  templateUrl: './loginemployee.component.html',
  styleUrls: ['./loginemployee.component.css']
})
export class LoginemployeeComponent implements OnInit {
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  logindetails: LoginDetails = new LoginDetails();
  submitted: boolean = false;
  userId: number = 0;
  constructor(private logindetailsservices: LoginDetailsService, private router: Router, private employeeDetailsService: EmployeeDetailsService) { }

  ngOnInit(): void {
  }
  goToHome() { }

  onFormSubmit() {
    this.submitted = true;
    console.log(this.logindetails);
    this.employeeDetailsService.getEmployeeDetailsByUserId(this.logindetails.userId).subscribe(data => {
      this.employeeDetails = data;
      console.log(this.employeeDetails);
      sessionStorage.setItem('employee',JSON.stringify(this.employeeDetails));
      
      this.logindetailsservices.validateUser(this.logindetails).subscribe(
        data => {
          this.logindetails = data;
          console.log("after calling service");

          console.log(this.logindetails);

          if (this.logindetails.role === 'HR') {
            this.router.navigate(['/hrhome']);
          }
          if (this.logindetails.role === 'PROJECT MANAGEWR') {
            this.router.navigate(['/projectmanagerhome']);
          }
          if (this.logindetails.role === 'TEAM LEADER') {
            this.router.navigate(['/teamleaderhome']);
          }
          if (this.logindetails.role === 'INTERVIEWER') {
            this.router.navigate(['/interviewerhome']);
          }
        }
      );
    });

  }
}
