package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.pojo.CandidateDetails;
import com.mindgate.main.pojo.DocumentDetails;

@Repository
public class CandidateDetailsRepository implements CandidateDetailsRepositoryInterface {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	CandidateDetailsRowMapper candidateDetailsRowMapper;

	private static final String INSERT_CANDIDATE_DETAILS = "INSERT INTO CANDIDATES_DETAILS(CANDIDATE_NAME, EMAIL,SKILL1, SKILL2, SKILL3, QUALIFICATION, EXPERIENCE, STATUS,LOCATION, REQUIREMENT_REQUEST_DETAILS_ID) VALUES(?,?,?,?,?,?,?,?,?,?)";
	private static final String SELECT_ALL_CANDIDATE_DETAILS = "SELECT * FROM CANDIDATES_DETAILS";
	private static final String SELECT_SINGLE_CANDIDATE_DETAIL = "SELECT * FROM CANDIDATES_DETAILS WHERE CANDIDATE_ID = ?";
	private static final String UPDATE_CANDIDATE_DETAILS = "UPDATE CANDIDATE_DETAILS SET CANDIDATE_NAME =?,EMAIL = ?, SKILL1= ?, SKILL2 = ?, SKILL3 = ? , QUALIFICATION = ? , EXPERIENCE = ? , STATUS =  ?,LOCATION=?, REQUIREMENT_REQUEST_DETAILS_ID = ?"
			+ "	WHERE CANDIDATE_ID = ?";
	private static final String DELETE_CANDIDATE_DETAILS = "DELETE CANDIDATE_DETAILS WHERE CANDIDATE_ID = ?";

	private int resultCount;

	@Override
	public boolean addNewCandidateDetails(CandidateDetails candidateDetails) {
		System.out.println("inserting document details into database");
		System.out.println(candidateDetails);

		Object[] args = { candidateDetails.getCandidateName(), candidateDetails.getEmail(),candidateDetails.getSkill1(), candidateDetails.getSkill2(), candidateDetails.getSkill3(),
				candidateDetails.getQualification(), candidateDetails.getExperience(), candidateDetails.getStatus(), candidateDetails.getLocation(),
				candidateDetails.getRequirementrequestetails().getRequirementRequestId() };

		resultCount = jdbcTemplate.update(INSERT_CANDIDATE_DETAILS, args);

		if (resultCount > 0)
			return true;
		else
			return false;

	}

	@Override
	public boolean updateCandidateDetailsDetailsByCandidateId(CandidateDetails candidateDetails) {
		Object[] args = {candidateDetails.getCandidateName(),candidateDetails.getEmail(), candidateDetails.getSkill1(), candidateDetails.getSkill2(), candidateDetails.getSkill3(),
				candidateDetails.getQualification(), candidateDetails.getExperience(), candidateDetails.getStatus(), candidateDetails.getLocation(),
				candidateDetails.getRequirementrequestetails(), candidateDetails.getCandidateId() };
		resultCount = jdbcTemplate.update(UPDATE_CANDIDATE_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public boolean deleteCandidateDetailsDetailsByCandidateId(int candidateId) {

		Object[] args = { candidateId };
		resultCount = jdbcTemplate.update(DELETE_CANDIDATE_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public CandidateDetails getCandidateDetailsByCandidateId(int candidateId) {
		Object[] args = { candidateId };
		CandidateDetails candidateDetails = jdbcTemplate.queryForObject(SELECT_SINGLE_CANDIDATE_DETAIL,candidateDetailsRowMapper,args);
		return candidateDetails;
	}

	@Override
	public List<CandidateDetails> getAllCandidateDetails() {
		List<CandidateDetails> allCandidates = jdbcTemplate.query(SELECT_ALL_CANDIDATE_DETAILS,candidateDetailsRowMapper);
		return allCandidates;
	}

}
