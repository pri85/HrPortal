import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teamleader-home',
  templateUrl: './teamleader-home.component.html',
  styleUrls: ['./teamleader-home.component.css']
})
export class TeamleaderHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
