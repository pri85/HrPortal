import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { RequirementRequestDetailsService } from 'src/app/service/requirement-request-details.service';

@Component({
  selector: 'app-requirement-request',
  templateUrl: './requirement-request.component.html',
  styleUrls: ['./requirement-request.component.css']
})
export class RequirementRequestComponent implements OnInit {

  allRequirementRequestDetails : RequirementRequestDetails [] =[] ;
  constructor(private requirementrequestdetailsService: RequirementRequestDetailsService, private router : Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.requirementrequestdetailsService.getAllRequirementRequest().subscribe(
      data =>{ 
        this.allRequirementRequestDetails =data;
        console.log(this.allRequirementRequestDetails);
      });
   }

   deleteRequirementRequestdetails(requirementrequestId : number){
    this.requirementrequestdetailsService.deleteRequirementRequestdetails(requirementrequestId).subscribe(data =>{
      console.log(data);
      this.reloadData();
    });
   
  }
  
  updateRequirementRequestdetails(requirementrequestId : number){
  console.log(requirementrequestId);
  this.router.navigate(['/updaterequirementrequest', requirementrequestId]);
  }
}
