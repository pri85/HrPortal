import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { InterviewDetails } from 'src/app/pojo/interviewdetails';
import { CandidateDetailsService } from 'src/app/service/candidate-details.service';
import { InterviewDetailsService } from 'src/app/service/interview-details.service';

@Component({
  selector: 'app-interview-details',
  templateUrl: './interview-details.component.html',
  styleUrls: ['./interview-details.component.css']
})
export class InterviewDetailsComponent implements OnInit {

  allInterviewDetails : InterviewDetails [] =[] ;

  constructor(private interviewDetailsService: InterviewDetailsService, private router : Router) { }

  ngOnInit(): void {
    this.reloadData()
  }
  reloadData(){
    this.interviewDetailsService.getAllInterviewDetails().subscribe(
      data =>{ 
        this.allInterviewDetails =data;
        console.log(this.allInterviewDetails);
      });
   }
}
