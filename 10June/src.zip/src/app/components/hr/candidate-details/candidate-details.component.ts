import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { CandidateDetailsService } from 'src/app/service/candidate-details.service';
import { CandidateComponent } from '../../candidate/candidate/candidate.component';

@Component({
  selector: 'app-candidate-details',
  templateUrl: './candidate-details.component.html',
  styleUrls: ['./candidate-details.component.css']
})
export class CandidateDetailsComponent implements OnInit {

  allCandidateDetails : CandidateDetails[] =[];

  
  constructor(private candidateDetailsService: CandidateDetailsService, private router : Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.candidateDetailsService.getAllCandidateDetails().subscribe(
      data =>{ 
        this.allCandidateDetails =data;
        console.log(this.allCandidateDetails);
      });
   }
   updateRequirementRequestdetails(){}
}
