import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interview-details',
  templateUrl: './interview-details.component.html',
  styleUrls: ['./interview-details.component.css']
})
export class InterviewDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
