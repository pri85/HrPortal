import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RequirementRequestDetails } from '../pojo/requirementrequestdetails';

@Injectable({
  providedIn: 'root'
})
export class RequirementRequestDetailsService {
  
  baseURL : string = "http://localhost:8080/requirementrequestdetails/requirementrequestdetail";

  constructor(private http: HttpClient) { }

  getSingleSingleRequirementRequest(requirementRequestId : number) : Observable<RequirementRequestDetails>{
    return this.http.get<RequirementRequestDetails>(this.baseURL+'/'+ requirementRequestId);
  }

  getAllRequirementRequest() : Observable<RequirementRequestDetails[]>{
    return this.http.get<RequirementRequestDetails[]>(this.baseURL);
    }
    addRequirementRequestdetails(requirementrequestdetails : RequirementRequestDetails) : Observable<RequirementRequestDetails> {
      console.log("in requrement request service");
      console.log(requirementrequestdetails);
      return this.http.post<RequirementRequestDetails>(this.baseURL , requirementrequestdetails);
  
    }

    deleteRequirementRequestdetails(requirementrequestId : number): Observable<boolean>{
      console.log('In DeleteEmployee '+ requirementrequestId);
      return this.http.delete<boolean>(this.baseURL+'/'+ requirementrequestId);
    }
  
    updateRequirementRequestdetails(requirementrequestdetails : RequirementRequestDetails) : Observable<boolean>{
      return this.http.put<boolean> (this.baseURL,requirementrequestdetails);
    }
    
}
