import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interviewer-home',
  templateUrl: './interviewer-home.component.html',
  styleUrls: ['./interviewer-home.component.css']
})
export class InterviewerHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
