import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requirement-request-status',
  templateUrl: './requirement-request-status.component.html',
  styleUrls: ['./requirement-request-status.component.css']
})
export class RequirementRequestStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
