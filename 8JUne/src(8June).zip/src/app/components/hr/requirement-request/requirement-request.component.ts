import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-requirement-request',
  templateUrl: './requirement-request.component.html',
  styleUrls: ['./requirement-request.component.css']
})
export class RequirementRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
