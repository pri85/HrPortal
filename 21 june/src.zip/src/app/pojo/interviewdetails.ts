import { CandidateDetails } from "./candidatedetails";
import { EmployeeDetails } from "./employeedetails";

export class InterviewDetails{
    interviewId : number = 0;
	candidateId : number = 0;
	interviewerId : number = 0;
	status : string = "";
	feedback : string = "";
	interviewDate : Date = new Date();
    candidateDetails: CandidateDetails = new CandidateDetails();
	employeeDetails : EmployeeDetails = new EmployeeDetails();
}