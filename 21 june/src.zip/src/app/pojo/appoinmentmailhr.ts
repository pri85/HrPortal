export class AppoinmentMailHr{
    
        recipient : string ="";
        msgBody : string ="";
        subject : string ="";
    
}