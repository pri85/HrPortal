export class LoginDetails{
    userId: number = 0;
    password: string = "";
    role: string = "";
}