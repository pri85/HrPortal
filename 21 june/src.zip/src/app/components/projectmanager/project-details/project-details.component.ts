import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { ProjectDetails } from 'src/app/pojo/projectdetails';
import { ProjectDetailsService } from 'src/app/service/project-details.service';

@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.css']
})
export class ProjectDetailsComponent implements OnInit {

  allProjectDetails:ProjectDetails[]=[];

  projectdetails : ProjectDetails = new ProjectDetails();
  employeeDetails: EmployeeDetails = new EmployeeDetails();

  
  constructor(private projectdetailsService: ProjectDetailsService, private router : Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
//get session
  this.employeeDetails = JSON.parse(sessionStorage.getItem("employee") || '{}');
  console.log(this.employeeDetails);

    // this.requirementrequestdetails.employeeDetails=this.employeeDetails;
    // this.requirementrequestdetails.projectDetails = this.employeeDetails.projectDetails;
    // console.log("-----------------");
    
    // console.log(this.requirementrequestdetails);

    this.projectdetailsService.getAllProjectDetailsByProjectId(this.employeeDetails.projectDetails.projectId).subscribe(
      data =>{
        //this.requirementrequestdetails=data;
        this.allProjectDetails=data;
        console.log('-----------------------------------');
        
        console.log(this.allProjectDetails);
        
      }
    );
  }
}
