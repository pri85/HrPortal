import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { RequirementRequestDetailsService } from 'src/app/service/requirement-request-details.service';

@Component({
  selector: 'app-edit-request',
  templateUrl: './edit-request.component.html',
  styleUrls: ['./edit-request.component.css']
})
export class EditRequestComponent implements OnInit {
  
  allRequirementRequestDetails : RequirementRequestDetails [] =[] ;
  employeeDetails : EmployeeDetails = new EmployeeDetails();
  constructor(private requirementrequestdetailsService: RequirementRequestDetailsService, private router : Router) { }

  ngOnInit(): void {
    this.employeeDetails = JSON.parse(sessionStorage.getItem("employee") || '{}');
    this.reloadData();

  }

  reloadData(){
    this.requirementrequestdetailsService.getAllRequirementRequestdetailsByProjectId(this.employeeDetails.projectDetails.projectId).subscribe(
      data =>{ 
        this.allRequirementRequestDetails =data;
        console.log(this.allRequirementRequestDetails);
      });
   }

   deleteRequirementRequestdetails(requirementrequestId : number){
    this.requirementrequestdetailsService.deleteRequirementRequestdetails(requirementrequestId).subscribe(data =>{
      console.log(data);
      this.reloadData();
    });
   
  }
  
  updateRequirementRequestdetails(requirementRequestDetails : RequirementRequestDetails){
    sessionStorage.setItem('requirementrequestdetails',JSON.stringify(requirementRequestDetails));
  console.log(requirementRequestDetails);
    this.router.navigate(['teamleaderhome/editrequirementrequestform']);
  }
}
