import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterviewDetailsInterviewerComponent } from './interview-details-interviewer.component';

describe('InterviewDetailsInterviewerComponent', () => {
  let component: InterviewDetailsInterviewerComponent;
  let fixture: ComponentFixture<InterviewDetailsInterviewerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterviewDetailsInterviewerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterviewDetailsInterviewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
