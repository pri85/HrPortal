import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { LoginDetails } from 'src/app/pojo/logindetails';
import { EmployeeDetailsService } from 'src/app/service/employee-details.service';
import { LoginDetailsService } from 'src/app/service/login-details.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-loginemployee',
  templateUrl: './loginemployee.component.html',
  styleUrls: ['./loginemployee.component.css']
})
export class LoginemployeeComponent implements OnInit {
  public loginForm! : FormGroup
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  logindetails: LoginDetails = new LoginDetails();
  submitted: boolean = false;
  userId: number = 0;
  msg : boolean = true;
  constructor(private  formBuilder : FormBuilder,private logindetailsservices: LoginDetailsService, private router: Router, private employeeDetailsService: EmployeeDetailsService) { }

  hide: boolean = true;
  flag : boolean = true;
  flag1 : boolean = true;
  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      userid :['',Validators.required],
      password : ['',Validators.required]

    })
  }
  goToHome() { }

  change(){
    this.hide = false;
  }
  career(){
    this.router.navigate(['/candidatehome']);
  }

  onFormSubmit() {
    this.submitted = false;
    console.log(this.logindetails);
    if (this.logindetails.userId === 0) {
      this.flag = false;
    } else if (this.logindetails.password === '') {
      this.flag1 = false;
    } else {
      this.flag = true;
      this.flag1 = true;
console.log(this.flag);
console.log(this.flag1);
    }
    this.employeeDetailsService.getEmployeeDetailsByUserId(this.logindetails.userId).subscribe(data => {
      this.employeeDetails = data;
      console.log(this.employeeDetails);
      sessionStorage.setItem('employee',JSON.stringify(this.employeeDetails));
      
      this.logindetailsservices.validateUser(this.logindetails).subscribe(
        data => {
          this.logindetails = data;
          
          if (this.logindetails.role ==='') {
            this.msg=true;
          } else {
            if (this.logindetails.role === 'HR') {
              this.router.navigate(['/hrhome']);
            }
            if (this.logindetails.role === 'PROJECT MANAGEWR') {
              this.router.navigate(['/projectmanagerhome']);
            }
            if (this.logindetails.role === 'TEAM LEADER') {
              this.router.navigate(['/teamleaderhome']);
            }
            if (this.logindetails.role === 'INTERVIEWER') {
              this.router.navigate(['/interviewerhome']);
            }
          }
         
        }
      );
    });

  }
  
  
}
