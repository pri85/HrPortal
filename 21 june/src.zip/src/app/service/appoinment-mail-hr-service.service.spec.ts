import { TestBed } from '@angular/core/testing';

import { AppoinmentMailHrServiceService } from './appoinment-mail-hr-service.service';

describe('AppoinmentMailHrServiceService', () => {
  let service: AppoinmentMailHrServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AppoinmentMailHrServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
