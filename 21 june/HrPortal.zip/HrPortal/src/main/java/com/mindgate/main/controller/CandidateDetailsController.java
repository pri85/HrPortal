package com.mindgate.main.controller;


import java.io.IOException;
import java.util.List;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mindgate.main.pojo.CandidateDetails;
import com.mindgate.main.pojo.InterviewDetails;
import com.mindgate.main.pojo.RequirementRequestDetails;
import com.mindgate.main.service.CandidateDetailsServiceInterface;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("candidatedetails")
public class CandidateDetailsController {

	@Autowired
	private CandidateDetailsServiceInterface candidateDetailsServiceInterface;
	
	@RequestMapping(value = "candidatedetail" , method = RequestMethod.GET)
	public List<CandidateDetails> getInterviewDetails(){
		return candidateDetailsServiceInterface.getAllCandidateDetails();
	}
	
	@RequestMapping(value = "candidatedetail/{candidateid}" , method = RequestMethod.GET)
	public CandidateDetails getDetails(@PathVariable int candidateid) {
		return candidateDetailsServiceInterface.getCandidateDetailsByCandidateId(candidateid);
	}
	
	@RequestMapping(value = "candidatedetail" , method =RequestMethod.POST)
	public boolean addNewCandidateDetails(@RequestBody CandidateDetails candidateDetails) {
		return candidateDetailsServiceInterface.addNewCandidateDetails(candidateDetails);
	}

	
	@RequestMapping(value = "inprocesscandidatedetail" ,method = RequestMethod.PUT)
	public boolean updateCandidateDetailsByStatus(@RequestBody CandidateDetails candidateDetails) {
		return candidateDetailsServiceInterface.updateCandidateDetailsByStatus(candidateDetails);
	}
	
	@RequestMapping(value = "inprocesscandidatedetail" , method = RequestMethod.GET)
	public List<CandidateDetails> getAllInprocessCandidateDetails(){
		return candidateDetailsServiceInterface.getAllInprocessCandidateDetails();
	}
	
	@RequestMapping(value = "newcandidatedetail" , method = RequestMethod.GET)
	public List<CandidateDetails> getAllNewCandidateDetails(){
		return candidateDetailsServiceInterface.getAllNewCandidateDetails();
	}
	@RequestMapping(value = "selectedcandidatedetail" , method = RequestMethod.GET)
	public List<CandidateDetails> getAllSelectedCandidateDetails(){
		return candidateDetailsServiceInterface.getAllSelectedCandidateDetails();
	}
	@RequestMapping(value = "rejectedcandidatedetail" , method = RequestMethod.GET)
	public List<CandidateDetails> getAllRejectedCandidateDetails(){
		return candidateDetailsServiceInterface.getAllRejectedCandidateDetails();
	}
	@RequestMapping(value = "pendingcandidatedetail" , method = RequestMethod.GET)
	public List<CandidateDetails> getAllPendingCandidateDetails(){
		return candidateDetailsServiceInterface.getAllPendingCandidateDetails();
	}
	//@PostMapping(value = "saveUserProfile")
	
	@RequestMapping(value = "saveUserProfile", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Response> saveUserProfile(@RequestParam("resume") MultipartFile file, @RequestParam("user") String user) throws JsonParseException, JsonMappingException, IOException{
		System.out.println("Insave User Profile");
		CandidateDetails candidateDetails = new ObjectMapper().readValue(user, CandidateDetails.class);
		if (candidateDetails.getDocument() != null) {
			System.out.println("In If");
			return new ResponseEntity<Response>(new Response(200), HttpStatus.OK);
		}
		return new ResponseEntity<Response>(new Response(1000), HttpStatus.BAD_REQUEST);
	}
}
