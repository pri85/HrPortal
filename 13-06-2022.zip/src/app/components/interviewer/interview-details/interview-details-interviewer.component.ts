import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { InterviewDetails } from 'src/app/pojo/interviewdetails';
import { CandidateDetailsService } from 'src/app/service/candidate-details.service';
import { InterviewDetailsService } from 'src/app/service/interview-details.service';

@Component({
  selector: 'app-interview-details-interviewer',
  templateUrl: './interview-details-interviewer.component.html',
  styleUrls: ['./interview-details-interviewer.component.css']
})
export class InterviewDetailsInterviewerComponent implements OnInit {

  allInterviewDetails : InterviewDetails[] = [];
  candidateDetails : CandidateDetails = new CandidateDetails();
  interviewDetails : InterviewDetails = new InterviewDetails();
  submitted : boolean = false;

  constructor(private interviewDetailsService: InterviewDetailsService,private candidateDetailsService : CandidateDetailsService,private router : Router, private route : ActivatedRoute) { }

  ngOnInit(): void {
    this.onReload();
  }

  update(interviewDetails: InterviewDetails){
  }
  goToHome(){}

  onInterviewSchedule(){}

  onReload(){
      this.interviewDetailsService.getAllInterviewDetailsAsPending().subscribe(
        data =>{
          this.allInterviewDetails = data;
        }
      );
  }
}
