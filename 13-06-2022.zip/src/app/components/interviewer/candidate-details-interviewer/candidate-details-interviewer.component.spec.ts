import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidateDetailsInterviewerComponent } from './candidate-details-interviewer.component';

describe('CandidateDetailsInterviewerComponent', () => {
  let component: CandidateDetailsInterviewerComponent;
  let fixture: ComponentFixture<CandidateDetailsInterviewerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CandidateDetailsInterviewerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidateDetailsInterviewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
