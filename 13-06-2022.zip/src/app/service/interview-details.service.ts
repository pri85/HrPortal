import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CandidateDetails } from '../pojo/candidatedetails';
import { InterviewDetails } from '../pojo/interviewdetails';

@Injectable({
  providedIn: 'root'
})
export class InterviewDetailsService {

  baseURL : string = "http://localhost:8080/interviewdetails";

  constructor(private http: HttpClient) { }

  getSingleInterviewDetails(interviewId : number) : Observable<InterviewDetails>{
    return this.http.get<InterviewDetails>(this.baseURL+'/interviewdetail/'+ interviewId);
  }

  getAllInterviewDetails() : Observable<InterviewDetails[]>{
    return this.http.get<InterviewDetails[]>(this.baseURL+'/interviewdetail');
    }

    addNewInterviewDetails(interviewDetails : InterviewDetails) : Observable<boolean> {
      console.log("in requrement request service");
      console.log(interviewDetails);
      return this.http.post<boolean>(this.baseURL+'/interviewdetail' , interviewDetails);
  
    }

    
}
