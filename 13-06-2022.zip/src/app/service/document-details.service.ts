import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DocumentDetails } from '../pojo/documentdetails';

@Injectable({
  providedIn: 'root'
})
export class DocumentDetailsService {

  baseURL : string = "http://localhost:8080/documentdetails/documentdetail";

  constructor(private http: HttpClient) { }

  getSingleDocumentDetails(documentId : number) : Observable<DocumentDetails>{
    return this.http.get<DocumentDetails>(this.baseURL+'/'+ documentId);
  }

  getAllDocumentDetails() : Observable<DocumentDetails[]>{
    return this.http.get<DocumentDetails[]>(this.baseURL);
    }
}
