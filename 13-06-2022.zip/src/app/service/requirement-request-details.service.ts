import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from '../pojo/employeedetails';
import { LoginDetails } from '../pojo/logindetails';
import { ProjectDetails } from '../pojo/projectdetails';
import { RequirementRequestDetails } from '../pojo/requirementrequestdetails';

@Injectable({
  providedIn: 'root'
})
export class RequirementRequestDetailsService {
  
  baseURL : string = "http://localhost:8080/requirementrequestdetails";

  constructor(private http: HttpClient) { }

  getSingleRequirementRequest(requirementRequestId : number) : Observable<RequirementRequestDetails>{
    return this.http.get<RequirementRequestDetails>(this.baseURL+'/'+'requirementrequestdetail/'+ requirementRequestId);
  }

  getAllRequirementRequest() : Observable<RequirementRequestDetails[]>{
    return this.http.get<RequirementRequestDetails[]>(this.baseURL+'/'+'requirementrequestdetail');
    }
    addRequirementRequestdetails(requirementrequestdetails : RequirementRequestDetails) : Observable<RequirementRequestDetails> {
      console.log("in requrement request service");
      console.log(requirementrequestdetails);
      return this.http.post<RequirementRequestDetails>(this.baseURL+'/requirementrequestdetail' , requirementrequestdetails);
  
    }

    deleteRequirementRequestdetails(requirementrequestId : number): Observable<boolean>{
      console.log('In DeleteEmployee '+ requirementrequestId);
      return this.http.delete<boolean>(this.baseURL+'/'+'requirementrequestdetail'+ requirementrequestId);
    }
  
    updateRequirementRequestdetails(requirementrequestdetails : RequirementRequestDetails) : Observable<EmployeeDetails[]>{
      return this.http.put<EmployeeDetails[]> (this.baseURL+'/'+'requirementrequestdetail',requirementrequestdetails);
    }
//terminate

    getAllRequirementRequestdetails(projectId : number) : Observable<RequirementRequestDetails[]>{
      return this.http.get<RequirementRequestDetails[]>(this.baseURL+'/'+'requirementrequestdetailbyprojectid/'+ projectId);
    }
    
    // updateRequirementRequestdetailsBySkillAndId(requirementrequestdetails : RequirementRequestDetails) : Observable<boolean>{
    //   return this.http.put<boolean> (this.baseURL+'/'+'requirementrequestdetail/'+ requirementrequestdetails);
    // }
    updateRequirementRequestStatus(requirementrequestdetails : RequirementRequestDetails) : Observable<boolean>{
      return this.http.put<boolean> (this.baseURL+'/'+'updaterequirementrequestdetailstatus',requirementrequestdetails);
    }

    updateRequirementRequestStatusAsSelected(requirementrequestdetails : RequirementRequestDetails) : Observable<boolean>{
      return this.http.put<boolean> (this.baseURL+'/'+'updaterequirementrequestdetailstatusasselected',requirementrequestdetails);
    }

    getAllRequirementRequestAsSelected() : Observable<RequirementRequestDetails[]>{
      return this.http.get<RequirementRequestDetails[]>(this.baseURL+'/'+'requirementrequestdetailasselected')
    }
}
