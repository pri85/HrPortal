import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicationFormComponent } from './components/candidate/application-form/application-form.component';
import { CandidateComponent } from './components/candidate/candidate/candidate.component';
import { CandidateDetailsComponent } from './components/hr/candidate-details/candidate-details.component';
import { HrHomeComponent } from './components/hr/hr-home/hr-home.component';
import { InterviewDetailsComponent } from './components/hr/interview-details/interview-details.component';
import { InterviewScheduleComponent } from './components/hr/interview-schedule/interview-schedule.component';
import { RequirementRequestComponent } from './components/hr/requirement-request/requirement-request.component';
import { CandidateDetailsInterviewerComponent } from './components/interviewer/candidate-details-interviewer/candidate-details-interviewer.component';
import { InterviewDetailsInterviewerComponent } from './components/interviewer/interview-details/interview-details-interviewer.component';
import { InterviewFormComponent } from './components/interviewer/interview-form/interview-form.component';
import { InterviewerHomeComponent } from './components/interviewer/interviewer-home/interviewer-home.component';
import { LoginemployeeComponent } from './components/login/loginemployee/loginemployee.component';
import { ProjectDetailsComponent } from './components/projectmanager/project-details/project-details.component';
import { ProjectManagerHomeComponent } from './components/projectmanager/project-manager-home/project-manager-home.component';
import { RequirementRequestStatusComponent } from './components/projectmanager/requirement-request-status/requirement-request-status.component';
import { UpdateRequirementRequestComponent } from './components/projectmanager/update-requirement-request/update-requirement-request.component';
import { EditRequestComponent } from './components/teamleader/edit-request/edit-request.component';
import { GenerateRequestComponent } from './components/teamleader/generate-request/generate-request.component';
import { TeamleaderHomeComponent } from './components/teamleader/teamleader-home/teamleader-home.component';


const routes: Routes = [
  { path: 'loginemployee', component: LoginemployeeComponent },
  {
    path: 'candidatehome', component: CandidateComponent,
    children: [
      { path: 'applicationform/:requirementRequestDetailsId', component: ApplicationFormComponent }
    ]
  },
  {
    path: 'projectmanagerhome', component: ProjectManagerHomeComponent,
    children: [
      { path: 'projectdetails', component: ProjectDetailsComponent },
      { path: 'requirementrequeststatus', component: RequirementRequestStatusComponent }

    ]
  },
  {
    path: 'teamleaderhome', component: TeamleaderHomeComponent,
    children: [
      { path: 'editrequest', component: EditRequestComponent },
      { path: 'generaterequest', component: GenerateRequestComponent }
    ]
  },
  {
    path: 'hrhome', component: HrHomeComponent,
    children: [
      { path: 'candidatedetails', component: CandidateDetailsComponent },
      { path: 'interviewdetails', component: InterviewDetailsComponent },
      { path: 'requirementrequest', component: RequirementRequestComponent },
      { path: 'interviewschedule/:candidateId', component: InterviewScheduleComponent }
    ]
  },
  {
    path: 'interviewerhome', component: InterviewerHomeComponent,
    children: [
      { path: 'interviewdetailsinterviewer', component: InterviewDetailsInterviewerComponent },
      { path: 'interviewform/:candidateId', component: InterviewFormComponent },
      { path: 'candidatedetailsinterviewer', component: CandidateDetailsInterviewerComponent},
  
      
    ]
  },
  { path: 'updaterequirementrequest/:projectId', component: UpdateRequirementRequestComponent },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
