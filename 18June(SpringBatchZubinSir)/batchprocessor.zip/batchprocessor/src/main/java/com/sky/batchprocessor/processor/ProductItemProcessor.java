package com.sky.batchprocessor.processor;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.item.ItemProcessor;

import com.sky.batchprocessor.model.InProduct;
import com.sky.batchprocessor.model.OutProduct;

public class ProductItemProcessor implements ItemProcessor<InProduct, OutProduct>{

	@Override
	public OutProduct process(InProduct product) throws Exception {

		final OutProduct transformedProduct = new OutProduct(product.getName(),product.getPrice(),product.getPrice()*0.9);
		return transformedProduct;
	}

	

}
