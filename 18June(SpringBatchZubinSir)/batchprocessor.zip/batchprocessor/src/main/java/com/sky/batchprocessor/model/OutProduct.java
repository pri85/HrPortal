package com.sky.batchprocessor.model;

public class OutProduct {

	private String name;
	private Double price;
	private Double disPrice;
	
	public OutProduct() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "OutProduct [name=" + name + ", price=" + price + ", disPrice=" + disPrice + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getDisPrice() {
		return disPrice;
	}

	public void setDisPrice(Double disPrice) {
		this.disPrice = disPrice;
	}

	public OutProduct(String name, Double price, Double disPrice) {
		super();
		this.name = name;
		this.price = price;
		this.disPrice = disPrice;
	}
	
}
