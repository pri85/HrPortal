package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.pojo.EmployeeDetails;
import com.mindgate.main.pojo.ProjectDetails;
import com.mindgate.main.pojo.RequirementRequestDetails;

public class RequirementRequestDetailsRowMapper implements RowMapper<RequirementRequestDetails>{

	@Override
	public RequirementRequestDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		
		int requirementRequestId = rs.getInt("employee_id");
		ProjectDetails projectDetails= null;
		String skill1 = rs.getString("employee_id");
		String skill2 = rs.getString("employee_id");
		String skill3 = rs.getString("employee_id");
		int experience = rs.getInt("employee_id");
		int vacancies = rs.getInt("employee_id");;
		EmployeeDetails employeeDetails=null;
		String status = rs.getString("employee_id");
		String role = rs.getString("employee_id");
		
		RequirementRequestDetails requirementRequestDetails = new RequirementRequestDetails(requirementRequestId,
				projectDetails,skill1,skill2,skill3,experience,vacancies,employeeDetails,status,role);
		return requirementRequestDetails;
	}

}
