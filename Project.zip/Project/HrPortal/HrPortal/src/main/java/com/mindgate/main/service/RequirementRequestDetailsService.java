package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.EmployeeDetails;
import com.mindgate.main.pojo.ProjectDetails;
import com.mindgate.main.pojo.RequirementRequestDetails;
import com.mindgate.main.repository.RequirementRequestDetailsRepositoryInterface;

@Service
public class RequirementRequestDetailsService implements RequirementRequestDetailsServiceInterface{

	@Autowired
	private RequirementRequestDetailsRepositoryInterface requirementRequestDetailsRepositoryInterface;
	
	@Override
	public boolean addNewRequirementRequest(RequirementRequestDetails requirementRequestDetails) {
		// TODO Auto-generated method stub
		return requirementRequestDetailsRepositoryInterface.addNewRequirementRequest(requirementRequestDetails);
	}

	@Override
	public boolean updateRequirementRequest(RequirementRequestDetails requirementRequestDetails) {
		// TODO Auto-generated method stub
		return requirementRequestDetailsRepositoryInterface.updateRequirementRequest(requirementRequestDetails);
	}

	@Override
	public boolean deleteRequirementRequest(int requirementRequestId) {
		// TODO Auto-generated method stub
		return requirementRequestDetailsRepositoryInterface.deleteRequirementRequest(requirementRequestId);
	}

	@Override
	public RequirementRequestDetails getRequirementRequestByRequirementRequestId(int requirementRequestId) {
		// TODO Auto-generated method stub
		return requirementRequestDetailsRepositoryInterface.getRequirementRequestByRequirementRequestId(requirementRequestId);
	}

	@Override
	public List<RequirementRequestDetails> getAllRequirementRequest() {
		// TODO Auto-generated method stub
		return requirementRequestDetailsRepositoryInterface.getAllRequirementRequest();
	}
	
}
