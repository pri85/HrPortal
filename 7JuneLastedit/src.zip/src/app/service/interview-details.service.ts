import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { InterviewDetails } from '../pojo/interviewdetails';

@Injectable({
  providedIn: 'root'
})
export class InterviewDetailsService {

  baseURL : string = "http://localhost:8080/interviewdetails/interviewdetail";

  constructor(private http: HttpClient) { }

  getSingleInterviewDetails(interviewId : number) : Observable<InterviewDetails>{
    return this.http.get<InterviewDetails>(this.baseURL+'/'+ interviewId);
  }

  getAllInterviewDetails() : Observable<InterviewDetails[]>{
    return this.http.get<InterviewDetails[]>(this.baseURL);
    }
}
