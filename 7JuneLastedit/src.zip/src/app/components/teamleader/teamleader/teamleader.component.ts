import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teamleader',
  templateUrl: './teamleader.component.html',
  styleUrls: ['./teamleader.component.css']
})
export class TeamleaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
