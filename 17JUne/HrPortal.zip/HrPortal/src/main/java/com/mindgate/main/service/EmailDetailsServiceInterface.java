package com.mindgate.main.service;

import com.mindgate.main.pojo.EmailDetails;

public interface EmailDetailsServiceInterface {
	
	String sendSimpleMail(EmailDetails details);
}
