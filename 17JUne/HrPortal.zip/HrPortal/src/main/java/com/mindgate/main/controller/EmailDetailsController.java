package com.mindgate.main.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.pojo.EmailDetails;
import com.mindgate.main.service.EmailDetailsServiceInterface;

@RestController
@RequestMapping("email")
public class EmailDetailsController {

	@Autowired
	private EmailDetailsServiceInterface emailServiceInterface;

	@RequestMapping(value = "sendemail" , method = RequestMethod.POST)
	public String sendMail(@RequestBody EmailDetails details) {
		return  emailServiceInterface.sendSimpleMail(details);
	}
}