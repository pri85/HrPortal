import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { CandidateDetailsService } from 'src/app/service/candidate-details.service';

@Component({
  selector: 'app-candidate-details-interviewer',
  templateUrl: './candidate-details-interviewer.component.html',
  styleUrls: ['./candidate-details-interviewer.component.css']
})
export class CandidateDetailsInterviewerComponent implements OnInit {

  allCandidateDetails : CandidateDetails[] = [];
  candidateDetails : CandidateDetails = new CandidateDetails();

  constructor(private candidateDetailsService : CandidateDetailsService,private router : Router, private route : ActivatedRoute) { }

  ngOnInit(): void {
    this.onReload();
    this.candidateDetails= JSON.parse(sessionStorage.getItem('interviewForm') || '{}');

    this.candidateDetails.candidateId = this.route.snapshot.params['candidateId'];
  }

  onReload(){
      this.candidateDetailsService.getAllInprocessCandidateDetails().subscribe(
        data =>{
          this.allCandidateDetails = data;
        }
      );
  }

  takeInterview(candidateDetails: CandidateDetails){
      this.router.navigate(['interviewerhome/interviewform',candidateDetails.candidateId]);
      //this.router.navigate(['hrhome/interviewschedule',candidateDetails.candidateId]);
      sessionStorage.setItem('interviewSchedule',JSON.stringify(candidateDetails));
  }
}
