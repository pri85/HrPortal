import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateInterviewDetailsFormComponent } from './update-interview-details-form.component';

describe('UpdateInterviewDetailsFormComponent', () => {
  let component: UpdateInterviewDetailsFormComponent;
  let fixture: ComponentFixture<UpdateInterviewDetailsFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateInterviewDetailsFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateInterviewDetailsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
