import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { InterviewDetails } from 'src/app/pojo/interviewdetails';
import { InterviewDetailsService } from 'src/app/service/interview-details.service';

@Component({
  selector: 'app-update-interview-details-form',
  templateUrl: './update-interview-details-form.component.html',
  styleUrls: ['./update-interview-details-form.component.css']
})
export class UpdateInterviewDetailsFormComponent implements OnInit {


  candidateDetails : CandidateDetails = new CandidateDetails();
  interviewDetails: InterviewDetails = new InterviewDetails();
  employeeDetails : EmployeeDetails = new EmployeeDetails();
  submitted : boolean = false;

  constructor(private interviewDetailsService: InterviewDetailsService, private router : Router) { }

  ngOnInit(): void {

          this.interviewDetails= JSON.parse(sessionStorage.getItem('interviewdetails') || '{}');

          this.employeeDetails = this.interviewDetails.employeeDetails;
          this.candidateDetails = this.interviewDetails.candidateDetails;

  }
  submit(){
    
  }

  goToHome(){
    this.router.navigate(['/interviewerhome']);
  }

  onInterviewSchedule(){
    this.submitted = true;
    this.interviewDetailsService.updateInterviewDetails(this.interviewDetails).subscribe(
      data =>{
        console.log(data);
        console.log('Updated SuccessFully!!');
        this.candidateDetails.status = this.interviewDetails.status;
        console.log(this.candidateDetails.status);
  
        
      }
    );
  }
}
