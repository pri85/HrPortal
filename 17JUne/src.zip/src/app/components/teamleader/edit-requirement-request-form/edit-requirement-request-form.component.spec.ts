import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditRequirementRequestFormComponent } from './edit-requirement-request-form.component';

describe('EditRequirementRequestFormComponent', () => {
  let component: EditRequirementRequestFormComponent;
  let fixture: ComponentFixture<EditRequirementRequestFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditRequirementRequestFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditRequirementRequestFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
