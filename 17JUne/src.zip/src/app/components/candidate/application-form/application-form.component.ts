import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { CandidateDetailsService } from 'src/app/service/candidate-details.service';

@Component({
  selector: 'app-application-form',
  templateUrl: './application-form.component.html',
  styleUrls: ['./application-form.component.css']
})
export class ApplicationFormComponent implements OnInit {

  hide : boolean = true;

  candidateDetails: CandidateDetails = new CandidateDetails();

  requirementRequestDetails: RequirementRequestDetails = new RequirementRequestDetails();

  submitted: boolean = false;
  constructor(private candidateDetailsService: CandidateDetailsService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.requirementRequestDetails = JSON.parse(sessionStorage.getItem('RequirementRequestDetails')|| '{}');
     
    this.requirementRequestDetails.requirementRequestId = this.route.snapshot.params['requirementRequestDetailsId'];
    console.log('ApplicationFormComponent');
    console.log(this.requirementRequestDetails);
  }

  onFormSubmit() {

  }

  login() {
    // this.router.navigate(['hrhome']);

    this.submitted = true;
    this.candidateDetails.requirementrequestetails = this.requirementRequestDetails;
    this.candidateDetailsService.addNewCandidateDetails(this.candidateDetails).subscribe(
      data => {

        this.candidateDetails.status = 'NEW';
        console.log('===============----------');

        console.log(data);

      }
    );
  }
  change(){
    this.hide = false;
  }

}
