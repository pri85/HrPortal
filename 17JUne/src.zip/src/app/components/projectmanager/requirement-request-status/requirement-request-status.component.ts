import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { RequirementRequestDetailsService } from 'src/app/service/requirement-request-details.service';

@Component({
  selector: 'app-requirement-request-status',
  templateUrl: './requirement-request-status.component.html',
  styleUrls: ['./requirement-request-status.component.css']
})
export class RequirementRequestStatusComponent implements OnInit {

  requirementrequestdetails: RequirementRequestDetails = new RequirementRequestDetails();
  
  allRequirementRequestDetails : RequirementRequestDetails [] =[] ;
  
  constructor(private requirementrequestdetailsService: RequirementRequestDetailsService, private router : Router) { }
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  userid: string = "";
  

  ngOnInit(): void {
    this.reloadData();
    
  }
 
   
   reloadData() {
//get session
    this.employeeDetails = JSON.parse(sessionStorage.getItem("employee") || '{}');
    console.log(this.employeeDetails);

    this.requirementrequestdetails.employeeDetails=this.employeeDetails;
    this.requirementrequestdetails.projectDetails = this.employeeDetails.projectDetails;
    console.log("-----------------");
    
    console.log(this.requirementrequestdetails);
    this.requirementrequestdetailsService.getAllRequirementRequestdetailsByProjectId(this.employeeDetails.projectDetails.projectId).subscribe(
      data =>{
        //this.requirementrequestdetails=data;
        this.allRequirementRequestDetails=data;
      }
    );
  }
  updateRequirementRequestdetails(requirementRequestId : number){

    //this.requirementrequestdetails.requirementRequestId=this.requirementrequestdetails.requirementRequestId-1;
    this.router.navigate(['updaterequirementrequest',requirementRequestId]);
   }
   


}
