import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { CandidateDetailsService } from 'src/app/service/candidate-details.service';
import { CandidateComponent } from '../../candidate/candidate/candidate.component';

@Component({
  selector: 'app-candidate-details',
  templateUrl: './candidate-details.component.html',
  styleUrls: ['./candidate-details.component.css']
})
export class CandidateDetailsComponent implements OnInit {

  allCandidateDetails : CandidateDetails[] =[];
  allNewCandidateDetails : CandidateDetails[] =[];
  allInprocessCandidateDetails : CandidateDetails[] =[];
  allSelectedCandidateDetails : CandidateDetails[] =[];
  allRejectedCandidateDetails : CandidateDetails[] =[];
  allPendingCandidateDetails : CandidateDetails[] =[];
  
  candidateId : number=0;

  submitted : boolean = false;
  
  constructor(private candidateDetailsService: CandidateDetailsService, private router : Router,private route : ActivatedRoute) { }

  ngOnInit(): void {
      this.reloadData();
     
      this.candidateId = this.route.snapshot.params['candidateId'];
  }

  reloadData(){

    this.candidateDetailsService.getAllCandidateDetails().subscribe(
      data =>{ 
        this.allCandidateDetails =data;
        console.log(this.allCandidateDetails);

      });


    //   this.candidateDetailsService.getAllNewCandidateDetails().subscribe(
    //     data =>{ 
    //       this.allNewCandidateDetails =data;
    //       console.log(this.allCandidateDetails);
    //     });
  
    //     this.candidateDetailsService.getAllInprocessCandidateDetails().subscribe(
    //       data =>{ 
    //         this.allInprocessCandidateDetails =data;
    //         console.log(this.allInprocessCandidateDetails);
    //     });
    
    //     this.candidateDetailsService.getAllSelectedCandidateDetails().subscribe(
    //       data =>{ 
    //         this.allSelectedCandidateDetails =data;
    //         console.log(this.allInprocessCandidateDetails);
    //   });
    //   this.candidateDetailsService.getAllRejectedCandidateDetails().subscribe(
    //     data =>{ 
    //       this.allRejectedCandidateDetails =data;
    //       console.log(this.allInprocessCandidateDetails);
    //   });

    //  this.candidateDetailsService.getAllPendingCandidateDetails().subscribe(
    //     data =>{ 
    //       this.allPendingCandidateDetails =data;
    //       console.log(this.allInprocessCandidateDetails);
    //   });
   }
  
  //  updateCandidateDetails(candidateDetails : CandidateDetails ){

  //   console.log('In Update Candidate Hr');
    
  //   candidateDetails.status = 'INPROCESS';
  //   this.candidateDetailsService.updateCandidateDetailsByStatus(candidateDetails).subscribe(
  //     data =>{
  //       console.log('In Update Candidate Hr data');
 
  //       this.router.navigate(['hrhome/interviewschedule',candidateDetails.candidateId]);
  //       sessionStorage.setItem('interviewSchedule',JSON.stringify(candidateDetails));
  //       console.log('--------------');
        
  //     }
  //   );
   
  //  }


  sendToInterviewer(candidateDetails : CandidateDetails){
    console.log('In Update Candidate Hr');
    this.submitted = true;
    candidateDetails.status = 'INPROCESS';
    this.candidateDetailsService.updateCandidateDetailsAsInprocess(candidateDetails).subscribe(
      data =>{
        console.log('In Update Candidate Hr data');
        
      }
    );
  }


  goToHome(){
    this.router.navigate(['/hrhome']);
  }

}
