import { TestBed } from '@angular/core/testing';

import { RequirementRequestDetailsService } from './requirement-request-details.service';

describe('RequirementRequestDetailsService', () => {
  let service: RequirementRequestDetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RequirementRequestDetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
