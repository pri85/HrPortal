import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EmployeeDetails } from '../pojo/employeedetails';
import { RequirementRequestDetails } from '../pojo/requirementrequestdetails';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {

  baseURL: string = "http://localhost:8080/employeedetails";

  constructor(private http: HttpClient) { }

  getSingleEmployeeDetails(employeeId: number): Observable<EmployeeDetails> {
    return this.http.get<EmployeeDetails>(this.baseURL + '/employeedetail/' + employeeId);
  }

  getEmployeeDetailsByUserId(userId: number): Observable<EmployeeDetails> {
    return this.http.get<EmployeeDetails>(this.baseURL + '/employeebyuserid/' + userId);
  }

  getAllEmployeeDetails(): Observable<EmployeeDetails[]> {
    return this.http.get<EmployeeDetails[]>(this.baseURL+ '/employeedetail');
  }
  getAllEmployeeByMatchingSkills(requirementRequestDetails: RequirementRequestDetails) :Observable<EmployeeDetails[]>{
    console.log(requirementRequestDetails);
    
    return this.http.post<EmployeeDetails[]>(this.baseURL+'/employeebyskill',requirementRequestDetails);
  }

  updateEmployeeDetails(employeeDetails: EmployeeDetails): Observable<boolean> {
    
    return this.http.put<boolean>(this.baseURL+'/updateprojectid',employeeDetails);
  }
}
