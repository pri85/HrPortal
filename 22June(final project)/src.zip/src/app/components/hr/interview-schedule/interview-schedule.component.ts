import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { InterviewDetails } from 'src/app/pojo/interviewdetails';
import { InterviewDetailsService } from 'src/app/service/interview-details.service';

@Component({
  selector: 'app-interview-schedule',
  templateUrl: './interview-schedule.component.html',
  styleUrls: ['./interview-schedule.component.css']
})
export class InterviewScheduleComponent implements OnInit {

  candidateDetails : CandidateDetails = new CandidateDetails();
  interviewDetails : InterviewDetails = new InterviewDetails();
  candidateId : number = 0;
  submitted : boolean = false;
  constructor(private router: Router,private route: ActivatedRoute, private interviewDetailsService: InterviewDetailsService) { }

  ngOnInit(): void {
    
    this.candidateDetails= JSON.parse(sessionStorage.getItem('interviewSchedule') || '{}');

    this.candidateDetails.candidateId = this.route.snapshot.params['candidateId'];

  }

  onInterviewSchedule(){
    this.submitted = true;
    this.interviewDetailsService.addNewInterviewDetails(this.interviewDetails).subscribe(
      data =>{
        // console.log(data);
        
      }
    );
  }

  goToHome(){
    this.router.navigate(['/hrhome']);
  }
}
