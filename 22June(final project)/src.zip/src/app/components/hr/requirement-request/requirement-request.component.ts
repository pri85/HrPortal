import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { RequirementRequestDetailsService } from 'src/app/service/requirement-request-details.service';

@Component({
  selector: 'app-requirement-request',
  templateUrl: './requirement-request.component.html',
  styleUrls: ['./requirement-request.component.css']
})
export class RequirementRequestComponent implements OnInit {

  submitted : boolean = false;
  allRequirementRequestDetails : RequirementRequestDetails [] =[] ;
  allRequirementRequestDetailsAsNew : RequirementRequestDetails [] =[] ;
  allRequirementRequestDetailsAsInprocess : RequirementRequestDetails [] =[] ;
  allRequirementRequestDetailsAsSelected : RequirementRequestDetails [] =[] ;
  constructor(private requirementrequestdetailsService: RequirementRequestDetailsService, private router : Router) { }

  ngOnInit(): void {
    this.reloadData();
  }

  reloadData(){
    this.requirementrequestdetailsService.getAllRequirementRequestAsNew().subscribe(
      data =>{ 
        this.allRequirementRequestDetailsAsNew =data;
        // console.log(this.allRequirementRequestDetails);
      });

      this.requirementrequestdetailsService.getAllRequirementRequestAsInprocess().subscribe(
        data =>{ 
          this.allRequirementRequestDetailsAsInprocess =data;
          // console.log(this.allRequirementRequestDetails);
        });
        this.requirementrequestdetailsService.getAllRequirementRequestAsSelected().subscribe(
          data =>{ 
            this.allRequirementRequestDetailsAsSelected =data;
            // console.log(this.allRequirementRequestDetails);
          });
   }

   
  
  updateRequirementRequestdetails(requirementrequestId : number){
  console.log(requirementrequestId);
  this.router.navigate(['/updaterequirementrequest', requirementrequestId]);
  }

  postonwebsite(requirementrequestdetails : RequirementRequestDetails){
    this.submitted= true;
    requirementrequestdetails.status = 'SELECTED';
   
    this.requirementrequestdetailsService.updateRequirementRequestStatusAsSelected(requirementrequestdetails).subscribe(
      data =>{
        this.reloadData();
        // console.log('selected status');   
        // console.log(data);
        
      }
    );
  }

  goToHome(){
    this.router.navigate(['/hrhome']);
  }
}
