import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { InterviewDetails } from 'src/app/pojo/interviewdetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { InterviewDetailsService } from 'src/app/service/interview-details.service';

@Component({
  selector: 'app-interview-form',
  templateUrl: './interview-form.component.html',
  styleUrls: ['./interview-form.component.css']
})
export class InterviewFormComponent implements OnInit {

  candidateDetails : CandidateDetails = new CandidateDetails();
  interviewDetails : InterviewDetails = new InterviewDetails();
  employeeDetails : EmployeeDetails = new EmployeeDetails();
  candidateId : number = 0;
  interviewerId : number = 0;
  submitted : boolean = false;

  constructor(private router : Router,  private interviewDetailsService: InterviewDetailsService, private route : ActivatedRoute) { }

  ngOnInit(): void {

          this.candidateDetails= JSON.parse(sessionStorage.getItem('interviewSchedule') || '{}');

          this.employeeDetails = JSON.parse(sessionStorage.getItem('employee') || '{}');

          this.candidateDetails.candidateId = this.route.snapshot.params['candidateId'];
          
          
  }

  goToHome(){
      this.router.navigate(['/interviewerhome']);
  }

  onInterviewSchedule(){}

  submit(){
    this.submitted = true;
    this.interviewDetails.candidateDetails = this.candidateDetails;
    this.interviewDetails.employeeDetails = this.employeeDetails;
    this.interviewDetails.status = 'PENDING';
    this.interviewDetailsService.addNewInterviewDetails(this.interviewDetails).subscribe(
      data =>{

        // console.log(data);
        
      }
    );
  }
}
