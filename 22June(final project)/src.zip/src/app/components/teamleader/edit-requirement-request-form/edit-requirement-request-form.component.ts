import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { RequirementRequestDetailsService } from 'src/app/service/requirement-request-details.service';

@Component({
  selector: 'app-edit-requirement-request-form',
  templateUrl: './edit-requirement-request-form.component.html',
  styleUrls: ['./edit-requirement-request-form.component.css']
})
export class EditRequirementRequestFormComponent implements OnInit {

  requirementrequestdetails : RequirementRequestDetails = new RequirementRequestDetails();
  submitted : boolean = false;
  employeeDetails : EmployeeDetails = new EmployeeDetails();
  allRequirementRequestDetails : RequirementRequestDetails [] =[] ;
  constructor(private requirementrequestdetailsService: RequirementRequestDetailsService, private router : Router) { }

  ngOnInit(): void {
    this.requirementrequestdetails = JSON.parse(sessionStorage.getItem('requirementrequestdetails') || '{}');
  }
  goToHome(){
    this.router.navigate(['/teamleaderhome']);
  }

  editRequirementRequestdetails(requirementRequestId : number){

  }
  onUpdate(){
    this.submitted= true;
    this.requirementrequestdetailsService.updateRequirementRequestByRequirementRequestId(this.requirementrequestdetails).subscribe(
      data =>{
        // console.log(data);
        
      }
    );
  }
}
