import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { RequirementRequestDetailsService } from 'src/app/service/requirement-request-details.service';

@Component({
  selector: 'app-generate-request',
  templateUrl: './generate-request.component.html',
  styleUrls: ['./generate-request.component.css']
})
export class GenerateRequestComponent implements OnInit {

  requirementrequestdetails: RequirementRequestDetails = new RequirementRequestDetails();
  submitted: Boolean = false;
  constructor(private requirementrequestdetailsservice: RequirementRequestDetailsService, private router: Router) { }
  employeeDetails: EmployeeDetails = new EmployeeDetails();
  userid: string = "";
  ngOnInit(): void {
    //get session
    this.employeeDetails = JSON.parse(sessionStorage.getItem("employee") || '{}');
    // console.log(this.employeeDetails);
    this.requirementrequestdetails.status = 'NEW';
  }
  goToHome() {
    this.router.navigate(['/teamleaderhome']);
   }
  onFormSubmit() {

    this.submitted = true;

    this.requirementrequestdetails.employeeDetails=this.employeeDetails;
    this.requirementrequestdetails.projectDetails = this.employeeDetails.projectDetails;
    
    // console.log(this.requirementrequestdetails);
    this.requirementrequestdetailsservice.addRequirementRequestdetails(this.requirementrequestdetails).subscribe(
      data => {
        this.requirementrequestdetails = data;
        // console.log("In generate request ts");

        // console.log(this.requirementrequestdetails);


      }
    );
  }
}
