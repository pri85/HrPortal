import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CandidateDetails } from 'src/app/pojo/candidatedetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { CandidateDetailsService } from 'src/app/service/candidate-details.service';

@Component({
  selector: 'app-application-form',
  templateUrl: './application-form.component.html',
  styleUrls: ['./application-form.component.css']
})
export class ApplicationFormComponent implements OnInit {

  hide : boolean = true;

  candidateName : boolean = true;
  email : boolean = true;
  skill1 : boolean = true;
  qualification : boolean = true;
  experience : boolean = true;
  location : boolean = true;

public userFile : any = File;

  candidateDetails: CandidateDetails = new CandidateDetails();

  requirementRequestDetails: RequirementRequestDetails = new RequirementRequestDetails();

  submitted: boolean = false;
  constructor(private candidateDetailsService: CandidateDetailsService, private router: Router, private route: ActivatedRoute, private fb : FormBuilder) { }

  ngOnInit(): void {

    this.requirementRequestDetails = JSON.parse(sessionStorage.getItem('RequirementRequestDetails')|| '{}');
     
    this.requirementRequestDetails.requirementRequestId = this.route.snapshot.params['requirementRequestDetailsId'];
    // console.log('ApplicationFormComponent');
    // console.log(this.requirementRequestDetails);
  }

  // reactiveForm = new FormGroup({
  //   candidateName: new FormControl('',[Validators.required]),
  //   email : new FormControl('', [Validators.required]),
  // });

  // submit(submitForm : FormGroup){

  //   if(submitForm.valid){
  //     const user = submitForm.value;
  //     const formData = new FormData();
  //     formData.append('user',JSON.stringify(user));
  //     formData.append('file', this.userFile);
  //     this.candidateDetailsService.saveUserProfile(formData).subscribe(
  //       data => {
  //         console.log('//////////in form/////');
          
  //         console.log(data);
          
  //       }
  //     );
  //   }else{
  //     this.validateFormFields(submitForm);
  //   }
  // }

  // validateFormFields(submitForm : FormGroup){

  // }
  onSelectFile(event : any){
      const file =event.target.files[0];
      // console.log(file);
      this.userFile = file;
      
  }

  onFormSubmit() {
    // this.router.navigate(['hrhome']);



    
   if (this.candidateDetails.candidateName ==='' ) {
      this.candidateName=false;
   }else if (this.candidateDetails.email ==='') {
     this.email=false;
   } else  if(this.candidateDetails.skill1 ===''){
     this.skill1 =false;
   } else if(this.candidateDetails.qualification ===''){
     this.qualification=false
   }else if(this.candidateDetails.experience ===''){
     this.experience=false;
   }else if(this.candidateDetails.location ===''){
     this.location=false;
   }

    this.candidateDetails.requirementrequestetails = this.requirementRequestDetails;
    this.candidateDetailsService.addNewCandidateDetails(this.candidateDetails).subscribe(
      data => {
        this.submitted = true;
        this.candidateDetails.status = 'NEW';

        // console.log(data);
        
      }
    );
  }
  change(){
    this.hide = false;
  }
  goToHome(){
    this.router.navigate(['/candidatehome']);
  }
}
