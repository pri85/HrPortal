import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { RequirementRequestDetailsService } from 'src/app/service/requirement-request-details.service';

@Component({
  selector: 'app-candidate',
  templateUrl: './candidate.component.html',
  styleUrls: ['./candidate.component.css']
})
export class CandidateComponent implements OnInit {

  requirementrequestId: number = 0;
  submitted: boolean = false;
  hide : boolean = true;

  allRequirementRequestDetails: RequirementRequestDetails[] = [];
  requirementRequestDetails: RequirementRequestDetails = new RequirementRequestDetails();

  constructor(private requirementRequestDetailsService: RequirementRequestDetailsService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.requirementrequestId = this.route.snapshot.params['requirementRequestDetailsId']

    this.reload();

  }




  reload() {
    this.requirementRequestDetailsService.getAllRequirementRequestAsSelected().subscribe(
      data => {
        // console.log(data);
        this.allRequirementRequestDetails = data;

      }

    );

  }
  apply(requirementRequestDetails: RequirementRequestDetails) {
    this.hide = false;
    // console.log("in apply");
    // console.log(requirementRequestDetails);
    // console.log("in apply");
    // console.log(requirementRequestDetails.requirementRequestId);

    sessionStorage.setItem('RequirementRequestDetails', JSON.stringify(requirementRequestDetails));
    this.router.navigate(['candidatehome/applicationform', requirementRequestDetails.requirementRequestId]);
  }
  

}
