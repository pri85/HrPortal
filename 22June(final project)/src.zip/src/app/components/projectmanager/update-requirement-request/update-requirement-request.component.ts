import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { EmployeeDetails } from 'src/app/pojo/employeedetails';
import { RequirementRequestDetails } from 'src/app/pojo/requirementrequestdetails';
import { EmployeeDetailsService } from 'src/app/service/employee-details.service';
import { RequirementRequestDetailsService } from 'src/app/service/requirement-request-details.service';

@Component({
  selector: 'app-update-requirement-request',
  templateUrl: './update-requirement-request.component.html',
  styleUrls: ['./update-requirement-request.component.css']
})
export class UpdateRequirementRequestComponent implements OnInit {

  nomployeetext : boolean = false;
  sendButton: boolean = false;
  allRequirementRequestDetails : RequirementRequestDetails [] =[] ;
  employeeBySkills : EmployeeDetails [] = [];
  requirementRequestDetails : RequirementRequestDetails = new RequirementRequestDetails();
  requirementRequestId : number = 0;
  sendtohrbutton : boolean = false;


  projectId : number = 0;
  constructor(private requirementRequestDetailsService: RequirementRequestDetailsService,private employeeDetailsService: EmployeeDetailsService,private router: Router, private route : ActivatedRoute) { }

  ngOnInit(): void {
    this.reloadData();
    
  }
 
  
  reloadData(){
    this.projectId =  this.route.snapshot.params['projectId'];
    
        this.requirementRequestDetailsService.getSingleRequirementRequest(this.projectId).subscribe(
          data =>{
            //this.requirementrequestdetails=data;
            this.requirementRequestDetails=data;
            // console.log(this.projectId);
            
            
            // console.log(this.requirementRequestDetails);

            
            this.employeeDetailsService.getAllEmployeeByMatchingSkills(this.requirementRequestDetails).subscribe(
              data =>{

                if(data === []){
                  this.sendtohrbutton = false;
                  // console.log(data);
                 
                }
                 
                  this.employeeBySkills=data;
                  // console.log(this.employeeBySkills);
                  this.requirementRequestId = this.requirementRequestDetails.requirementRequestId;
                
                
                
              }
            );
            
            
          }
        );
        
  }
  onUpdateEmployeeDetails(employeeDetails: EmployeeDetails){
    employeeDetails.projectDetails.projectId =this.requirementRequestDetails.employeeDetails.projectDetails.projectId;
    employeeDetails.pincode = this.requirementRequestId;
    // console.log(employeeDetails.pincode);
    
    this.employeeDetailsService.updateEmployeeDetails(employeeDetails).subscribe(
      data =>{
        // console.log(data);
        // console.log('true');
        this.reloadData();
      }
    );
  }

  onSendToHr(){
    this.sendButton = true;
    this.requirementRequestDetails.status ='INPROCESS';
    this.requirementRequestDetailsService.updateRequirementRequestStatus(this.requirementRequestDetails).subscribe(
      data =>{
        // console.log(data);
        
      }
    );
  }
  goToHome(){
    this.router.navigate(['/projectmanagerhome']);
  }

}
