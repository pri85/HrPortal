import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AppoinmentMailHr } from '../pojo/appoinmentmailhr';

@Injectable({
  providedIn: 'root'
})
export class AppoinmentMailHrServiceService {


  baseURL : string = "http://localhost:8080/email/sendemail";

  constructor(private http: HttpClient) { }

  sendappoinmentmail(){

  }
  addNewCandidateDetails(appoinmentMailHr : AppoinmentMailHr) : Observable<String> {
      // console.log("in requrement request service");
      // console.log(appoinmentMailHr);
      return this.http.post<String>(this.baseURL+'/candidatedetail/',appoinmentMailHr);
  
    }
}
