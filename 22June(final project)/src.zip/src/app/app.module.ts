import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginemployeeComponent } from './components/login/loginemployee/loginemployee.component';
import { CandidateComponent } from './components/candidate/candidate/candidate.component';
import { InterviewerHomeComponent } from './components/interviewer/interviewer-home/interviewer-home.component';
import { GenerateRequestComponent } from './components/teamleader/generate-request/generate-request.component';
import { EditRequestComponent } from './components/teamleader/edit-request/edit-request.component';
import { ProjectDetailsComponent } from './components/projectmanager/project-details/project-details.component';
import { RequirementRequestStatusComponent } from './components/projectmanager/requirement-request-status/requirement-request-status.component';
import { RequirementRequestComponent } from './components/hr/requirement-request/requirement-request.component';
import { InterviewDetailsComponent } from './components/hr/interview-details/interview-details.component';
import { CandidateDetailsComponent } from './components/hr/candidate-details/candidate-details.component';
import { HrHomeComponent } from './components/hr/hr-home/hr-home.component';
import { TeamleaderHomeComponent } from './components/teamleader/teamleader-home/teamleader-home.component';
import { ProjectManagerHomeComponent } from './components/projectmanager/project-manager-home/project-manager-home.component';
import { UpdateRequirementRequestComponent } from './components/projectmanager/update-requirement-request/update-requirement-request.component';
import { ApplicationFormComponent } from './components/candidate/application-form/application-form.component';
import { InterviewScheduleComponent } from './components/hr/interview-schedule/interview-schedule.component';
import { InterviewFormComponent } from './components/interviewer/interview-form/interview-form.component';
import { CandidateDetailsInterviewerComponent } from './components/interviewer/candidate-details-interviewer/candidate-details-interviewer.component';
import { InterviewDetailsInterviewerComponent } from './components/interviewer/interview-details/interview-details-interviewer.component';
import { UpdateInterviewDetailsFormComponent } from './components/interviewer/update-interview-details-form/update-interview-details-form.component';
import { EditRequirementRequestFormComponent } from './components/teamleader/edit-requirement-request-form/edit-requirement-request-form.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginemployeeComponent,
    ProjectManagerHomeComponent,
    TeamleaderHomeComponent,
    HrHomeComponent,
    CandidateComponent,
    InterviewerHomeComponent,
    InterviewerHomeComponent,
    GenerateRequestComponent,
    EditRequestComponent,
    ProjectDetailsComponent,
    RequirementRequestStatusComponent,
    RequirementRequestComponent,
    InterviewDetailsComponent,
    CandidateDetailsComponent,
    HrHomeComponent,
    TeamleaderHomeComponent,
    ProjectManagerHomeComponent,
    UpdateRequirementRequestComponent,
    ApplicationFormComponent,
    InterviewDetailsInterviewerComponent,
    InterviewScheduleComponent,
    InterviewFormComponent,
    CandidateDetailsInterviewerComponent,
    UpdateInterviewDetailsFormComponent,
    EditRequirementRequestFormComponent,
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserModule /* or CommonModule */, 
      FormsModule, ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
