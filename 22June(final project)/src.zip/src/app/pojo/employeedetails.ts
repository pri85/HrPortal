import { LoginDetails } from "./logindetails";
import { ProjectDetails } from "./projectdetails";

export class EmployeeDetails{
     employeeId : number = 0;
	 firstName : string = "";
	 lastName : string = "";
	 contactNumber : number = 0;
	 designation : string = "";
	 salary : number = 0.0;
	 projectDetails : ProjectDetails = new ProjectDetails();
	 address : string = "";
	 city : string = "";
	 state : string = "";
	 pincode : number = 0;
	 loginDetails : LoginDetails = new LoginDetails();
}