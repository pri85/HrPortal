package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.CandidateDetails;

@Service
public class CandidateDetailsService implements CandidateDetailsServiceInterface {

	@Autowired
	private CandidateDetailsServiceInterface candidateDetailsServiceInterface;

	@Override
	public boolean addNewCandidateDetails(CandidateDetails candidateDetails) {

		return candidateDetailsServiceInterface.addNewCandidateDetails(candidateDetails);
	}

	@Override
	public boolean updateCandidateDetailsByCandidateId(CandidateDetails candidateDetails) {

		return candidateDetailsServiceInterface.updateCandidateDetailsByCandidateId(candidateDetails);
	}

	@Override
	public boolean deleteCandidateDetailsByCandidateId(int candidateId) {

		return candidateDetailsServiceInterface.deleteCandidateDetailsByCandidateId(candidateId);
	}

	@Override
	public CandidateDetails getCandidateDetailsByCandidateId(int candidateId) {

		return candidateDetailsServiceInterface.getCandidateDetailsByCandidateId(candidateId);
	}

	@Override
	public List<CandidateDetails> getAllCandidateDetails() {

		return candidateDetailsServiceInterface.getAllCandidateDetails();
	}

}
