package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.LoginDetails;
import com.mindgate.main.pojo.ProjectDetails;

@Service
public class LoginDetailsService implements LoginDetailsServiceInterface{

	@Autowired
	private LoginDetailsServiceInterface loginDetailsServiceInterface;
	
	@Override
	public boolean addNewLoginDetails(LoginDetails loginDetails) {
		
		return loginDetailsServiceInterface.addNewLoginDetails(loginDetails);
	}

	@Override
	public boolean updateLoginDetailsByLoginId(LoginDetails loginDetails) {

		return loginDetailsServiceInterface.updateLoginDetailsByLoginId(loginDetails);
	}

	@Override
	public boolean deleteLoginDetailsByLoginId(int loginId) {

		return loginDetailsServiceInterface.deleteLoginDetailsByLoginId(loginId);
	}

	@Override
	public LoginDetails getLoginDetailsByLoginId(int loginId) {

		return loginDetailsServiceInterface.getLoginDetailsByLoginId(loginId);
	}

	@Override
	public List<LoginDetails> getAllLoginDetails() {

		return loginDetailsServiceInterface.getAllLoginDetails();
	}

}
