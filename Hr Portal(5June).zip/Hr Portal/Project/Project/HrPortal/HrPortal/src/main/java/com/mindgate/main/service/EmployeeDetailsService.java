package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.EmployeeDetails;

@Service
public class EmployeeDetailsService implements EmployeeDetailsServiceInterface{

	@Autowired
	private EmployeeDetailsServiceInterface employeeDetailsServiceInterface; 
	
	@Override
	public boolean addNewEmployee(EmployeeDetails employeeDetails) {

		return employeeDetailsServiceInterface.addNewEmployee(employeeDetails);
	}

	@Override
	public boolean updateEmployeeDetailsByEmployeeId(EmployeeDetails employeeDetails) {
		// TODO Auto-generated method stub
		return employeeDetailsServiceInterface.updateEmployeeDetailsByEmployeeId(employeeDetails);
	}

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		return employeeDetailsServiceInterface.deleteEmployeeByEmployeeId(employeeId);
	}

	@Override
	public EmployeeDetails getEmployeeByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		return employeeDetailsServiceInterface.getEmployeeByEmployeeId(employeeId);
	}

	@Override
	public List<EmployeeDetails> getAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDetailsServiceInterface.getAllEmployee();
	}

}
