package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.pojo.InterviewDetails;

@Repository
public class InterviewDetailsRepository implements InterviewDetailsRepositoryInterface{

	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final String INSERT_INTERVIEW_DETAILS = "INSERT INTO INTERVIEW_DETAILS(STATUS, CANDIDATE_ID, FEEDBACK, INTERVIEWER_ID) VALUES(?,?,?,?)";
	private static final String SELECT_ALL_INTERVIEW_DETAILS = "SELECT * FROM INTERVIEW_DETAILS";
	private static final String SELECT_SINGLE_INTERVIEW_DETAILS = "SELECT * FROM INTERVIEW_DETAILS WHERE INTERVIEW_ID = ?";
	private static final String UPDATE_INTERVIEW_DETAILS = "UPDATE INTERVIEW_DETAILS SET STATUS = ?, CANDIDATE_ID = ?, FEEDBACK = ?, INTERVIEWER_ID =?"
			+ "	WHERE INTERVIEW_ID = ?";
	private static final String DELETE_INTERVIEW_DETAILS = "DELETE INTERVIEW_DETAILS WHERE INTERVIEW_ID = ?";

	private int resultCount;

	
	@Override
	public boolean addNewInterviewDetails(InterviewDetails interviewDetails) {
		System.out.println("inserting new INTERVIEW details into database");
		System.out.println(interviewDetails);

		Object[] args = { interviewDetails.getStatus(), interviewDetails.getCandidateId(), interviewDetails.getFeedback(),interviewDetails.getInterviewerId() };

		resultCount = jdbcTemplate.update(INSERT_INTERVIEW_DETAILS, args);

		if (resultCount > 0)
			return true;
		else
			return false;	}

	@Override
	public boolean updateInterviewDetailsByInterviewId(InterviewDetails interviewDetails) {
		Object[] args = { interviewDetails.getStatus(), interviewDetails.getCandidateId(), interviewDetails.getFeedback(),interviewDetails.getInterviewerId(),interviewDetails.getInterviewId()};
		resultCount = jdbcTemplate.update(UPDATE_INTERVIEW_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public boolean deleteInterviewDetailsByInterviewId(int interviewId) {
		Object[] args = { interviewId };
		resultCount = jdbcTemplate.update(DELETE_INTERVIEW_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;	}

	@Override
	public InterviewDetails getInterviewDetailsById(int interviewId) {

		Object[] args = { interviewId };
		InterviewDetails employee = jdbcTemplate.queryForObject(SELECT_SINGLE_INTERVIEW_DETAILS, args, new InterviewDetailsRowMapper());
		return employee;
	}

	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		
		List<InterviewDetails> allEmployees = jdbcTemplate.query(SELECT_ALL_INTERVIEW_DETAILS, new InterviewDetailsRowMapper());
		return allEmployees;
	}

}
