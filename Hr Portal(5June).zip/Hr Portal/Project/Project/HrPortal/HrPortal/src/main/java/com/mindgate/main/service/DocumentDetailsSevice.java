package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.DocumentDetails;

@Service
public class DocumentDetailsSevice implements DocumentDetailsSeviceInterface{

	@Autowired
	private DocumentDetailsSeviceInterface documentDetailsSeviceInterface;
	@Override
	public boolean addNewDocumentDetails(DocumentDetails documentDetails) {

		return documentDetailsSeviceInterface.addNewDocumentDetails(documentDetails);
	}

	@Override
	public boolean updateDocumentDetailsByDocumentId(DocumentDetails documentDetails) {

		return documentDetailsSeviceInterface.updateDocumentDetailsByDocumentId(documentDetails);
	}

	@Override
	public boolean deleteDocumentDetailsByDocumentId(int documentId) {

		return documentDetailsSeviceInterface.deleteDocumentDetailsByDocumentId(documentId);
	}

	@Override
	public DocumentDetails getDocumentDetailsByDocumentId(int documentId) {

		return documentDetailsSeviceInterface.getDocumentDetailsByDocumentId(documentId);
	}

	@Override
	public List<DocumentDetails> getAllDocumentDetails() {

		return documentDetailsSeviceInterface.getAllDocumentDetails();
	}

}
