package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.pojo.EmployeeDetails;

@Repository
public class EmployeeDetailsRepository implements EmployeeDetailsRepositoryInterface{

	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private static final String INSERT_EMPLOYEE_DETAILS = "INSERT INTO EMPLOYEE_DETAILS(FIRST_NAME, LAST_NAME ,CONTACT_NO ,DESIGNATION, SALARY, PROJECT_ID ,ADDRESS, CITY ,STATE, PINCODE ,USER_ID) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)";
	private static final String SELECT_ALL_EMPLOYEE_DETAILS = "SELECT * FROM EMPLOYEE_DETAILS";
	private static final String SELECT_SINGLE_EMPLOYEE_DETAILS = "SELECT * FROM EMPLOYEE_DETAILS WHERE EMPLOYEE_ID = ?";
	private static final String UPDATE_EMPLOYEE_DETAILS = "UPDATE EMPLOYEE_DETAILS SET FIRST_NAME = ?, LAST_NAME = ?, CONTACT_NO = ? ,DESIGNATION = ?, SALARY = ?, PROJECT_ID = ?, ADDRESS = ? ,CITY= ? ,STATE = ? ,PINCODE = ?, USER_ID =?"
			+ "	WHERE EMPLOYEE_ID = ?";
	private static final String DELETE_EMPLOYEE_DETAILS = "DELETE EMPLOYEE_DETAILS WHERE EMPLOYEE_ID = ?";

	private int resultCount;

	
	@Override
	public boolean addNewEmployee(EmployeeDetails employeeDetails) {
		System.out.println("inserting new employee into database");
		System.out.println(employeeDetails);

		Object[] args = { employeeDetails.getFirstName(), employeeDetails.getLastName(), employeeDetails.getContactNumber(), employeeDetails.getDesignation(), employeeDetails.getSalary(), employeeDetails.getProjectDetails(), employeeDetails.getAddress(), employeeDetails.getCity(),employeeDetails.getState(), employeeDetails.getPincode(), employeeDetails.getLoginDetails()};

		resultCount = jdbcTemplate.update(INSERT_EMPLOYEE_DETAILS, args);

		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public boolean updateEmployeeDetailsByEmployeeId(EmployeeDetails employeeDetails) {
		Object[] args = { employeeDetails.getFirstName(), employeeDetails.getLastName(), employeeDetails.getContactNumber(), employeeDetails.getDesignation(), employeeDetails.getSalary(), employeeDetails.getProjectDetails(), employeeDetails.getAddress(), employeeDetails.getCity(),employeeDetails.getState(), employeeDetails.getPincode(), employeeDetails.getLoginDetails(), employeeDetails.getEmployeeId() };
		resultCount = jdbcTemplate.update(UPDATE_EMPLOYEE_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public boolean deleteEmployeeByEmployeeId(int employeeId) {
		Object[] args = { employeeId };
		resultCount = jdbcTemplate.update(DELETE_EMPLOYEE_DETAILS, args);
		if (resultCount > 0)
			return true;
		else
			return false;
	}

	@Override
	public EmployeeDetails getEmployeeByEmployeeId(int employeeId) {
		Object[] args = { employeeId };
		EmployeeDetails employeeDetails = jdbcTemplate.queryForObject(SELECT_SINGLE_EMPLOYEE_DETAILS, args, new EmployeeDetailsRowMapper());
		return employeeDetails;
	}

	@Override
	public List<EmployeeDetails> getAllEmployee() {
		List<EmployeeDetails> allEmployeeDetails = jdbcTemplate.query(SELECT_ALL_EMPLOYEE_DETAILS, new EmployeeDetailsRowMapper());
		return allEmployeeDetails;
	}

}
