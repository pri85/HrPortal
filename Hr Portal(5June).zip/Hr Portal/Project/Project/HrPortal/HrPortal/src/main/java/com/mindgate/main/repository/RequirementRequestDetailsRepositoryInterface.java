package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.pojo.RequirementRequestDetails;

public interface RequirementRequestDetailsRepositoryInterface {
	
	public boolean addNewRequirementRequest(RequirementRequestDetails requirementRequestDetails);
	public boolean updateRequirementRequestByRequirementRequestId(RequirementRequestDetails requirementRequestDetails);
	public boolean deleteRequirementRequestByRequirementRequestId(int requirementRequestId);
	public RequirementRequestDetails getRequirementRequestByRequirementRequestId(int requirementRequestId);
	public List<RequirementRequestDetails> getAllRequirementRequest();

}
