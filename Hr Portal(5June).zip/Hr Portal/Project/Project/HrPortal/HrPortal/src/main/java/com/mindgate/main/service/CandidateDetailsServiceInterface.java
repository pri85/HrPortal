package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.pojo.CandidateDetails;

public interface CandidateDetailsServiceInterface {

	public boolean addNewCandidateDetails(CandidateDetails candidateDetails);
	public boolean updateCandidateDetailsByCandidateId(CandidateDetails candidateDetails);
	public boolean deleteCandidateDetailsByCandidateId(int candidateId);
	public CandidateDetails getCandidateDetailsByCandidateId(int candidateId);
	public List<CandidateDetails> getAllCandidateDetails();
}
