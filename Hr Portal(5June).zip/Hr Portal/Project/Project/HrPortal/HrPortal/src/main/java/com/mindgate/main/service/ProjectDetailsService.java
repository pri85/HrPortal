package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.ProjectDetails;

@Service
public class ProjectDetailsService implements ProjectDetailsServiceInterface{

	@Autowired
	private ProjectDetailsServiceInterface projectDetailsServiceInterface; 
	
	@Override
	public boolean addNewProjectDetails(ProjectDetails projectDetails) {
		return projectDetailsServiceInterface.addNewProjectDetails(projectDetails);
	}

	@Override
	public boolean updateProjectDeatilsByProjectId(ProjectDetails projectDetails) {
		return projectDetailsServiceInterface.updateProjectDeatilsByProjectId(projectDetails);
	}

	@Override
	public boolean deleteProjectDetailsByProjectId(int projectId) {
		return projectDetailsServiceInterface.deleteProjectDetailsByProjectId(projectId);
	}

	@Override
	public ProjectDetails getProjectDetailsByProjectId(int projectId) {
		return projectDetailsServiceInterface.getProjectDetailsByProjectId(projectId);
	}

	@Override
	public List<ProjectDetails> getAllProjectsDetails() {
		return projectDetailsServiceInterface.getAllProjectsDetails();
	}

	

}
