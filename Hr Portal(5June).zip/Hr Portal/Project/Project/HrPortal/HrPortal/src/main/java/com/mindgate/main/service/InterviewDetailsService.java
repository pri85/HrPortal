package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.pojo.InterviewDetails;

@Service
public class InterviewDetailsService implements InterviewDetailsServiceInterface {

	@Autowired
	private InterviewDetailsServiceInterface interviewDetailsServiceInterface; 
	@Override
	public boolean addNewInterviewDetails(InterviewDetails interviewDetails) {

		return interviewDetailsServiceInterface.addNewInterviewDetails(interviewDetails);
	}

	@Override
	public boolean updateInterviewDetailsByInterviewId(InterviewDetails interviewDetails) {

		return interviewDetailsServiceInterface.updateInterviewDetailsByInterviewId(interviewDetails);
	}

	@Override
	public boolean deleteInterviewDetailsByInterviewId(int interviewId) {
		// TODO Auto-generated method stub
		return interviewDetailsServiceInterface.deleteInterviewDetailsByInterviewId(interviewId);
	}

	@Override
	public InterviewDetails getInterviewDetailsById(int interviewId) {
		// TODO Auto-generated method stub
		return interviewDetailsServiceInterface.getInterviewDetailsById(interviewId);
	}

	@Override
	public List<InterviewDetails> getAllInterviewDetails() {
		// TODO Auto-generated method stub
		return interviewDetailsServiceInterface.getAllInterviewDetails();
	}

}
