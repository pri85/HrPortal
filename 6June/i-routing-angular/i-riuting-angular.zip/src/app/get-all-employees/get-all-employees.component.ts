import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from 'src/app/pojo/employee';
import { EmployeeCRUDServiceService } from 'src/app/services/employee-crudservice.service';

@Component({
  selector: 'app-get-all-employees',
  templateUrl: './get-all-employees.component.html',
  styleUrls: ['./get-all-employees.component.css']
})
export class GetAllEmployeesComponent implements OnInit {

 
  allEmployees : Employee[] = [];
  constructor(private employeeCRUDService : EmployeeCRUDServiceService, private router : Router) { }

  ngOnInit(): void {
    this.reloadData();
  }


  getdetails(employeeId : number){
    console.log(employeeId);
    this.router.navigate(['/employeedetails',employeeId]);
    
  }

  reloadData(){
    this.employeeCRUDService.getAllEmployees().subscribe(
      data => {
        this.allEmployees = data;
        console.log(this.allEmployees);
        
      }
    );
  }

  deleteEmployee(employeeId : number){
    this.employeeCRUDService.deleteEmployee(employeeId).subscribe(
      data => {
        console.log(data);
        this.reloadData();
      }
    );
  }

  updateEmployee(employeeId : number){
    console.log(employeeId);
    this.router.navigate(['/updateemployee',employeeId]);
  }
}
