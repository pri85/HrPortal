import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route } from '@angular/router';
import { Employee } from '../pojo/employee';
import { EmployeeCRUDServiceService } from '../services/employee-crudservice.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.css']
})
export class EmployeeDetailsComponent implements OnInit {

  employeeId : number = 0;
  employee: Employee = new Employee();

  constructor(private employeeCRUDService : EmployeeCRUDServiceService , private route : ActivatedRoute) { }

  ngOnInit(): void {
    this.employeeId = this.route.snapshot.params['employeeId'];
    this.loadEmployeeDetails(this.employeeId);
  }

  loadEmployeeDetails(employeeId : number){
    this.employeeCRUDService.getSingleEmployee(employeeId).subscribe(
      data => {
        this.employee = data;
      }
    );
  }
}
