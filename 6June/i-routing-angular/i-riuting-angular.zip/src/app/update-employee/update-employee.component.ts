import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../pojo/employee';
import { EmployeeCRUDServiceService } from '../services/employee-crudservice.service';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  submitted : boolean = false;
  employeeId : number = 0;
  employee: Employee = new Employee();
  constructor(private route : ActivatedRoute, private employeeCRUDService : EmployeeCRUDServiceService, private router: Router) { }

  ngOnInit(): void {
    this.employeeId = this.route.snapshot.params['employeeId'];
    this.employeeCRUDService.getSingleEmployee(this.employeeId).subscribe(
      data => {
        this.employee = data;
      }
    );
  
  }

  onFormSubmit(){
      this.employeeCRUDService.updateEmployee(this.employee).subscribe(
        data =>{
          this.submitted = true;
          console.log(data);
          
        }
      );
  }
  goToHome(){
    this.router.navigate(['/getallemployees']);
  }

}
