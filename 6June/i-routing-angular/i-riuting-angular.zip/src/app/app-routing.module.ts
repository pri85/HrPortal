import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddnewemployeeComponent } from './addnewemployee/addnewemployee.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { GetAllEmployeesComponent } from './get-all-employees/get-all-employees.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';

const routes: Routes = [
  {path:'', redirectTo:'getallemployees', pathMatch: 'full'},
  {path:'addemployee', component: AddnewemployeeComponent},
  {path:'getallemployees', component: GetAllEmployeesComponent},
  {path:'employeedetails/:employeeId', component: EmployeeDetailsComponent},
  {path:'updateemployee/:employeeId', component: UpdateEmployeeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
