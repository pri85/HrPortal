import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../pojo/employee';
import { EmployeeCRUDServiceService } from '../services/employee-crudservice.service';

@Component({
  selector: 'app-addnewemployee',
  templateUrl: './addnewemployee.component.html',
  styleUrls: ['./addnewemployee.component.css']
})
export class AddnewemployeeComponent implements OnInit {

  employee : Employee = new Employee();
  submitted : boolean = false;

  constructor(private employeeService : EmployeeCRUDServiceService, private router : Router) { }

  ngOnInit(): void {
  }

  onFormSubmit(){
    this.submitted = true;
    console.log(this.employee);
    this.employeeService.addEmployee(this.employee).subscribe(
      data => {
        console.log(data);
        
      }
    );
    // alert("Form Submitted Successfully");
    
  }

  goToHome(){
    this.router.navigate(['/getallemployees']);
  }


}
